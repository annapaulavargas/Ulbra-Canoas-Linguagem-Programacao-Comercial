namespace ControlesDiversos_csharp
{
    partial class frm_ControlesDatas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label7 = new System.Windows.Forms.Label();
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.TabC_Picture = new System.Windows.Forms.TabPage();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Button1 = new System.Windows.Forms.Button();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.TabC_UpDown = new System.Windows.Forms.TabPage();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.Label5 = new System.Windows.Forms.Label();
            this.TrackBar1 = new System.Windows.Forms.TrackBar();
            this.Label4 = new System.Windows.Forms.Label();
            this.NumericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.NumericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.TabC_DTPicker = new System.Windows.Forms.TabPage();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.Label1 = new System.Windows.Forms.Label();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.TabC_Month = new System.Windows.Forms.TabPage();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.MonthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.OpenFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.TabControl1.SuspendLayout();
            this.TabC_Picture.SuspendLayout();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.TabC_UpDown.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericUpDown1)).BeginInit();
            this.TabC_DTPicker.SuspendLayout();
            this.TabC_Month.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label7
            // 
            this.Label7.Location = new System.Drawing.Point(12, 26);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(488, 40);
            this.Label7.TabIndex = 5;
            this.Label7.Text = "TabControl,  DateTimePicker, PictureBox, Panel, ComboBox, MonthCalendar, NumericU" +
                "pDown e TrackBar";
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.TabC_Picture);
            this.TabControl1.Controls.Add(this.TabPage1);
            this.TabControl1.Controls.Add(this.TabC_UpDown);
            this.TabControl1.Controls.Add(this.TabC_DTPicker);
            this.TabControl1.Controls.Add(this.TabC_Month);
            this.TabControl1.Location = new System.Drawing.Point(31, 80);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(517, 211);
            this.TabControl1.TabIndex = 4;
            // 
            // TabC_Picture
            // 
            this.TabC_Picture.BackColor = System.Drawing.Color.Gray;
            this.TabC_Picture.Controls.Add(this.Panel1);
            this.TabC_Picture.Controls.Add(this.ComboBox1);
            this.TabC_Picture.Controls.Add(this.Label6);
            this.TabC_Picture.Controls.Add(this.Button1);
            this.TabC_Picture.Location = new System.Drawing.Point(4, 22);
            this.TabC_Picture.Name = "TabC_Picture";
            this.TabC_Picture.Size = new System.Drawing.Size(509, 185);
            this.TabC_Picture.TabIndex = 3;
            this.TabC_Picture.Text = "PictureBox";
            this.TabC_Picture.UseVisualStyleBackColor = true;
            // 
            // Panel1
            // 
            this.Panel1.AutoScroll = true;
            this.Panel1.AutoSize = true;
            this.Panel1.BackColor = System.Drawing.Color.Silver;
            this.Panel1.Controls.Add(this.PictureBox1);
            this.Panel1.Location = new System.Drawing.Point(204, 28);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(168, 124);
            this.Panel1.TabIndex = 4;
            // 
            // PictureBox1
            // 
            this.PictureBox1.BackColor = System.Drawing.Color.Maroon;
            this.PictureBox1.Location = new System.Drawing.Point(4, 4);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(144, 49);
            this.PictureBox1.TabIndex = 0;
            this.PictureBox1.TabStop = false;
            // 
            // ComboBox1
            // 
            this.ComboBox1.Items.AddRange(new object[] {
            "AutoSize",
            "Normal",
            "CenterImage",
            "StretchImage"});
            this.ComboBox1.Location = new System.Drawing.Point(88, 36);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(92, 21);
            this.ComboBox1.TabIndex = 3;
            this.ComboBox1.Text = "ComboBox1";
            this.ComboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(20, 40);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(57, 13);
            this.Label6.TabIndex = 2;
            this.Label6.Text = "SizeMode:";
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(72, 72);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(64, 32);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Carrega Imagem";
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // TabPage1
            // 
            this.TabPage1.BackgroundImage = global::ControlesDiversos_csharp.Properties.Resources.hotplug;
            this.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TabPage1.Location = new System.Drawing.Point(4, 22);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Size = new System.Drawing.Size(509, 185);
            this.TabPage1.TabIndex = 4;
            this.TabPage1.Text = "teste";
            this.TabPage1.UseVisualStyleBackColor = true;
            // 
            // TabC_UpDown
            // 
            this.TabC_UpDown.Controls.Add(this.numericUpDown3);
            this.TabC_UpDown.Controls.Add(this.Label5);
            this.TabC_UpDown.Controls.Add(this.TrackBar1);
            this.TabC_UpDown.Controls.Add(this.Label4);
            this.TabC_UpDown.Controls.Add(this.NumericUpDown2);
            this.TabC_UpDown.Controls.Add(this.NumericUpDown1);
            this.TabC_UpDown.Location = new System.Drawing.Point(4, 22);
            this.TabC_UpDown.Name = "TabC_UpDown";
            this.TabC_UpDown.Size = new System.Drawing.Size(509, 185);
            this.TabC_UpDown.TabIndex = 2;
            this.TabC_UpDown.Text = "NumericUpDown";
            this.TabC_UpDown.UseVisualStyleBackColor = true;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(181, 107);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            100000000,
            0,
            0,
            -2147483648});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(250, 20);
            this.numericUpDown3.TabIndex = 5;
            this.numericUpDown3.ThousandsSeparator = true;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(24, 48);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(46, 20);
            this.Label5.TabIndex = 4;
            this.Label5.Text = "Valor";
            // 
            // TrackBar1
            // 
            this.TrackBar1.Location = new System.Drawing.Point(242, 44);
            this.TrackBar1.Maximum = 1000;
            this.TrackBar1.Minimum = 1;
            this.TrackBar1.Name = "TrackBar1";
            this.TrackBar1.Size = new System.Drawing.Size(160, 45);
            this.TrackBar1.TabIndex = 3;
            this.TrackBar1.Value = 1;
            this.TrackBar1.Scroll += new System.EventHandler(this.TrackBar1_Scroll);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(24, 12);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(108, 20);
            this.Label4.TabIndex = 2;
            this.Label4.Text = "Espa�amento";
            // 
            // NumericUpDown2
            // 
            this.NumericUpDown2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumericUpDown2.Location = new System.Drawing.Point(114, 44);
            this.NumericUpDown2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumericUpDown2.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.NumericUpDown2.Name = "NumericUpDown2";
            this.NumericUpDown2.Size = new System.Drawing.Size(122, 26);
            this.NumericUpDown2.TabIndex = 1;
            this.NumericUpDown2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumericUpDown2.ValueChanged += new System.EventHandler(this.NumericUpDown2_ValueChanged);
            // 
            // NumericUpDown1
            // 
            this.NumericUpDown1.DecimalPlaces = 2;
            this.NumericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NumericUpDown1.Location = new System.Drawing.Point(140, 8);
            this.NumericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NumericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumericUpDown1.Name = "NumericUpDown1";
            this.NumericUpDown1.Size = new System.Drawing.Size(82, 26);
            this.NumericUpDown1.TabIndex = 0;
            this.NumericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumericUpDown1.ValueChanged += new System.EventHandler(this.NumericUpDown1_ValueChanged);
            // 
            // TabC_DTPicker
            // 
            this.TabC_DTPicker.Controls.Add(this.dateTimePicker3);
            this.TabC_DTPicker.Controls.Add(this.dateTimePicker2);
            this.TabC_DTPicker.Controls.Add(this.Label1);
            this.TabC_DTPicker.Controls.Add(this.DateTimePicker1);
            this.TabC_DTPicker.Location = new System.Drawing.Point(4, 22);
            this.TabC_DTPicker.Name = "TabC_DTPicker";
            this.TabC_DTPicker.Size = new System.Drawing.Size(509, 185);
            this.TabC_DTPicker.TabIndex = 0;
            this.TabC_DTPicker.Text = "DateTimePicker";
            this.TabC_DTPicker.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker3.Location = new System.Drawing.Point(310, 40);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.ShowUpDown = true;
            this.dateTimePicker3.Size = new System.Drawing.Size(197, 20);
            this.dateTimePicker3.TabIndex = 3;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd/MM/yyyy   HH:mm:ss";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(47, 78);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.ShowCheckBox = true;
            this.dateTimePicker2.ShowUpDown = true;
            this.dateTimePicker2.Size = new System.Drawing.Size(204, 20);
            this.dateTimePicker2.TabIndex = 2;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label1.Location = new System.Drawing.Point(92, 16);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(15, 15);
            this.Label1.TabIndex = 1;
            this.Label1.Text = "0";
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateTimePicker1.Location = new System.Drawing.Point(47, 40);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(237, 20);
            this.DateTimePicker1.TabIndex = 0;
            this.DateTimePicker1.ValueChanged += new System.EventHandler(this.DateTimePicker1_ValueChanged);
            // 
            // TabC_Month
            // 
            this.TabC_Month.Controls.Add(this.Label3);
            this.TabC_Month.Controls.Add(this.Label2);
            this.TabC_Month.Controls.Add(this.MonthCalendar1);
            this.TabC_Month.Location = new System.Drawing.Point(4, 22);
            this.TabC_Month.Name = "TabC_Month";
            this.TabC_Month.Size = new System.Drawing.Size(509, 185);
            this.TabC_Month.TabIndex = 1;
            this.TabC_Month.Text = "MonthCalendar";
            this.TabC_Month.UseVisualStyleBackColor = true;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label3.Location = new System.Drawing.Point(239, 81);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(15, 15);
            this.Label3.TabIndex = 3;
            this.Label3.Text = "0";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label2.Location = new System.Drawing.Point(239, 57);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(15, 15);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "0";
            // 
            // MonthCalendar1
            // 
            this.MonthCalendar1.Location = new System.Drawing.Point(0, 9);
            this.MonthCalendar1.Name = "MonthCalendar1";
            this.MonthCalendar1.TabIndex = 0;
            this.MonthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.MonthCalendar1_DateChanged);
            // 
            // OpenFileDialog1
            // 
            this.OpenFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1_FileOk);
            // 
            // frm_ControlesDatas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 345);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.TabControl1);
            this.Name = "frm_ControlesDatas";
            this.Text = "TabControl,  DateTimePicker, PictureBox, ComboBox, MonthCalendar, NumericUpDown e" +
                " TrackBar";
            this.Load += new System.EventHandler(this.frm_ControlesDatas_Load);
            this.TabControl1.ResumeLayout(false);
            this.TabC_Picture.ResumeLayout(false);
            this.TabC_Picture.PerformLayout();
            this.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.TabC_UpDown.ResumeLayout(false);
            this.TabC_UpDown.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumericUpDown1)).EndInit();
            this.TabC_DTPicker.ResumeLayout(false);
            this.TabC_DTPicker.PerformLayout();
            this.TabC_Month.ResumeLayout(false);
            this.TabC_Month.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TabPage TabC_DTPicker;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.DateTimePicker DateTimePicker1;
        internal System.Windows.Forms.TabPage TabC_Month;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.MonthCalendar MonthCalendar1;
        internal System.Windows.Forms.TabPage TabPage1;
        internal System.Windows.Forms.TabPage TabC_Picture;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.TabPage TabC_UpDown;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TrackBar TrackBar1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.NumericUpDown NumericUpDown2;
        internal System.Windows.Forms.NumericUpDown NumericUpDown1;
        internal System.Windows.Forms.OpenFileDialog OpenFileDialog1;
        internal System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
    }
}