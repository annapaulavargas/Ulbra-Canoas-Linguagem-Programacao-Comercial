using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_ControlesDatas : Form
    {
        public frm_ControlesDatas()
        {
            InitializeComponent();
        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            Label1.Text = DateTimePicker1.Value.ToShortDateString();
            Label1.Text = DateTimePicker1.Value.ToLongDateString ();
            Label1.Text = DateTimePicker1.Value.ToString("d/M/y H:m:s");
        }

        private void MonthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            Label2.Text = "MonthCalendar1.SelectionStart = " + MonthCalendar1.SelectionStart.ToShortDateString();
            Label3.Text = "MonthCalendar1.SelectionEnd = " + MonthCalendar1.SelectionEnd.ToLongDateString();


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog1.Filter = "Bitmap (*.bmp) | *.BMP| �cones (*.ico)| *.ICO | Todos os arquivos | *.*";
            OpenFileDialog1.DefaultExt = "*.BMP";
            OpenFileDialog1.ShowDialog();


        }

        private void OpenFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName);

        }

        private void NumericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown2.Increment = NumericUpDown1.Value ;
        }

        private void NumericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            TrackBar1.Value = (int) NumericUpDown2.Value;
        }

        private void TrackBar1_Scroll(object sender, EventArgs e)
        {
            NumericUpDown2.Value = TrackBar1.Value;
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (Convert.ToString (ComboBox1.SelectedItem  ))
            {
                case "AutoSize":
                    PictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                    break;
                case "Normal":
                    PictureBox1.SizeMode = PictureBoxSizeMode.Normal;
                    break;
                case "CenterImage":
                    PictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
                    break;
                case "StretchImage":
                    PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;
            }
        }

        private void frm_ControlesDatas_Load(object sender, EventArgs e)
        {
            TabControl1.TabPages[0].Text = "xxxxxx";
            TabC_Picture.Text = "yyyyyy";
            DateTimePicker1.Value = new DateTime(2010,12,10);
        }
    }
}