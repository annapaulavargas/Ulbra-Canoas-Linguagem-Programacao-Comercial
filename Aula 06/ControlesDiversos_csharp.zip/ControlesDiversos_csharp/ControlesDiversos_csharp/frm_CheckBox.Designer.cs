namespace ControlesDiversos_csharp
{
    partial class frm_CheckBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_CheckBox));
            this.Label7 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.CheckBox3 = new System.Windows.Forms.CheckBox();
            this.CheckBox4 = new System.Windows.Forms.CheckBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.chk_opcao4 = new System.Windows.Forms.CheckBox();
            this.chk_opcao3 = new System.Windows.Forms.CheckBox();
            this.chk_opcao2 = new System.Windows.Forms.CheckBox();
            this.chk_opcao1 = new System.Windows.Forms.CheckBox();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.lbl_Resultado = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label7
            // 
            this.Label7.Location = new System.Drawing.Point(32, 258);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(336, 16);
            this.Label7.TabIndex = 48;
            this.Label7.Text = "Panel: Propriedades BackGroundImage, AutoScroll e BorderStyle";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(168, 162);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(194, 13);
            this.Label5.TabIndex = 47;
            this.Label5.Text = "Image <> None, ImageAlign e TextAlign";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(40, 162);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(74, 13);
            this.Label6.TabIndex = 46;
            this.Label6.Text = "Image = None";
            // 
            // CheckBox3
            // 
            this.CheckBox3.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox3.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox3.Image")));
            this.CheckBox3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CheckBox3.Location = new System.Drawing.Point(280, 194);
            this.CheckBox3.Name = "CheckBox3";
            this.CheckBox3.Size = new System.Drawing.Size(96, 40);
            this.CheckBox3.TabIndex = 45;
            this.CheckBox3.Text = "CheckBox3";
            this.CheckBox3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CheckBox3.CheckedChanged += new System.EventHandler(this.CheckBox3_CheckedChanged);
            // 
            // CheckBox4
            // 
            this.CheckBox4.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox4.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox4.Image")));
            this.CheckBox4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CheckBox4.Location = new System.Drawing.Point(176, 194);
            this.CheckBox4.Name = "CheckBox4";
            this.CheckBox4.Size = new System.Drawing.Size(96, 40);
            this.CheckBox4.TabIndex = 44;
            this.CheckBox4.Text = "CheckBox4";
            this.CheckBox4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.CheckBox4.CheckedChanged += new System.EventHandler(this.CheckBox4_CheckedChanged);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(158, 50);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(194, 13);
            this.Label4.TabIndex = 43;
            this.Label4.Text = "Image <> None, ImageAlign e TextAlign";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(48, 50);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(74, 13);
            this.Label3.TabIndex = 42;
            this.Label3.Text = "Image = None";
            // 
            // CheckBox1
            // 
            this.CheckBox1.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox1.Image")));
            this.CheckBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CheckBox1.Location = new System.Drawing.Point(168, 98);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(120, 16);
            this.CheckBox1.TabIndex = 41;
            this.CheckBox1.Text = "CheckBox1";
            this.CheckBox1.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // CheckBox2
            // 
            this.CheckBox2.Checked = true;
            this.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBox2.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox2.Image")));
            this.CheckBox2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CheckBox2.Location = new System.Drawing.Point(168, 74);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(104, 16);
            this.CheckBox2.TabIndex = 40;
            this.CheckBox2.Text = "CheckBox2";
            this.CheckBox2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CheckBox2.CheckedChanged += new System.EventHandler(this.CheckBox2_CheckedChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(24, 138);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(168, 13);
            this.Label2.TabIndex = 39;
            this.Label2.Text = "Propriedade Appearance = Button";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(24, 34);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(170, 13);
            this.Label1.TabIndex = 38;
            this.Label1.Text = "Propriedade Appearance = Normal";
            // 
            // chk_opcao4
            // 
            this.chk_opcao4.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_opcao4.Location = new System.Drawing.Point(32, 218);
            this.chk_opcao4.Name = "chk_opcao4";
            this.chk_opcao4.Size = new System.Drawing.Size(96, 32);
            this.chk_opcao4.TabIndex = 37;
            this.chk_opcao4.Text = "chk_opcao4";
            this.chk_opcao4.CheckedChanged += new System.EventHandler(this.chk_opcao4_CheckedChanged);
            // 
            // chk_opcao3
            // 
            this.chk_opcao3.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_opcao3.Checked = true;
            this.chk_opcao3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_opcao3.Location = new System.Drawing.Point(32, 186);
            this.chk_opcao3.Name = "chk_opcao3";
            this.chk_opcao3.Size = new System.Drawing.Size(96, 32);
            this.chk_opcao3.TabIndex = 36;
            this.chk_opcao3.Text = "chk_opcao3";
            this.chk_opcao3.CheckedChanged += new System.EventHandler(this.chk_opcao3_CheckedChanged);
            // 
            // chk_opcao2
            // 
            this.chk_opcao2.Location = new System.Drawing.Point(40, 98);
            this.chk_opcao2.Name = "chk_opcao2";
            this.chk_opcao2.Size = new System.Drawing.Size(88, 16);
            this.chk_opcao2.TabIndex = 34;
            this.chk_opcao2.Text = "chk_opcao2";
            this.chk_opcao2.CheckedChanged += new System.EventHandler(this.chk_opcao2_CheckedChanged);
            // 
            // chk_opcao1
            // 
            this.chk_opcao1.Checked = true;
            this.chk_opcao1.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.chk_opcao1.Location = new System.Drawing.Point(40, 74);
            this.chk_opcao1.Name = "chk_opcao1";
            this.chk_opcao1.Size = new System.Drawing.Size(96, 16);
            this.chk_opcao1.TabIndex = 33;
            this.chk_opcao1.Text = "chk_opcao1";
            this.chk_opcao1.CheckedChanged += new System.EventHandler(this.chk_opcao1_CheckedChanged);
            // 
            // Panel1
            // 
            this.Panel1.AutoScroll = true;
            this.Panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Panel1.BackgroundImage")));
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Panel1.Controls.Add(this.lbl_Resultado);
            this.Panel1.Location = new System.Drawing.Point(106, 277);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(256, 64);
            this.Panel1.TabIndex = 35;
            // 
            // lbl_Resultado
            // 
            this.lbl_Resultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Resultado.Location = new System.Drawing.Point(144, 20);
            this.lbl_Resultado.Name = "lbl_Resultado";
            this.lbl_Resultado.Size = new System.Drawing.Size(100, 40);
            this.lbl_Resultado.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripDropDownButton1,
            this.toolStripLabel1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(477, 25);
            this.toolStrip1.TabIndex = 49;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(86, 22);
            this.toolStripLabel1.Text = "toolStripLabel1";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 407);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(477, 22);
            this.statusStrip1.TabIndex = 50;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // frm_CheckBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 429);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.CheckBox3);
            this.Controls.Add(this.CheckBox4);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.CheckBox1);
            this.Controls.Add(this.CheckBox2);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.chk_opcao4);
            this.Controls.Add(this.chk_opcao3);
            this.Controls.Add(this.chk_opcao2);
            this.Controls.Add(this.chk_opcao1);
            this.Controls.Add(this.Panel1);
            this.Name = "frm_CheckBox";
            this.Text = "CheckBox e Panel";
            this.Panel1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.CheckBox CheckBox3;
        internal System.Windows.Forms.CheckBox CheckBox4;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.CheckBox CheckBox2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.CheckBox chk_opcao4;
        internal System.Windows.Forms.CheckBox chk_opcao3;
        internal System.Windows.Forms.CheckBox chk_opcao2;
        internal System.Windows.Forms.CheckBox chk_opcao1;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label lbl_Resultado;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}