namespace ControlesDiversos_csharp
{
    partial class frm_Timer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Timer));
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Timer3 = new System.Windows.Forms.Timer(this.components);
            this.CheckBox3 = new System.Windows.Forms.CheckBox();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.lbl_Relogio = new System.Windows.Forms.Label();
            this.lbl_Cronometro = new System.Windows.Forms.Label();
            this.Timer2 = new System.Windows.Forms.Timer(this.components);
            this.Label2 = new System.Windows.Forms.Label();
            this.lbl_Letreiro = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xxxxxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Timer1
            // 
            this.Timer1.Interval = 200;
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // CheckBox2
            // 
            this.CheckBox2.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBox2.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox2.Image")));
            this.CheckBox2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CheckBox2.Location = new System.Drawing.Point(308, 124);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(172, 48);
            this.CheckBox2.TabIndex = 21;
            this.CheckBox2.Text = "Liga Cron�metro";
            this.CheckBox2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CheckBox2.CheckedChanged += new System.EventHandler(this.CheckBox2_CheckedChanged);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(24, 196);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(82, 24);
            this.Label3.TabIndex = 20;
            this.Label3.Text = "Rel�gio";
            // 
            // Timer3
            // 
            this.Timer3.Interval = 1000;
            this.Timer3.Tick += new System.EventHandler(this.Timer3_Tick);
            // 
            // CheckBox3
            // 
            this.CheckBox3.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBox3.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox3.Image")));
            this.CheckBox3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CheckBox3.Location = new System.Drawing.Point(312, 192);
            this.CheckBox3.Name = "CheckBox3";
            this.CheckBox3.Size = new System.Drawing.Size(172, 48);
            this.CheckBox3.TabIndex = 22;
            this.CheckBox3.Text = "Liga Rel�gio";
            this.CheckBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CheckBox3.CheckedChanged += new System.EventHandler(this.CheckBox3_CheckedChanged);
            // 
            // CheckBox1
            // 
            this.CheckBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBox1.Image = ((System.Drawing.Image)(resources.GetObject("CheckBox1.Image")));
            this.CheckBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CheckBox1.Location = new System.Drawing.Point(172, 64);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(168, 48);
            this.CheckBox1.TabIndex = 19;
            this.CheckBox1.Text = "Liga Letreiro";
            this.CheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CheckBox1.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // lbl_Relogio
            // 
            this.lbl_Relogio.AutoSize = true;
            this.lbl_Relogio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Relogio.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Relogio.Location = new System.Drawing.Point(152, 192);
            this.lbl_Relogio.Name = "lbl_Relogio";
            this.lbl_Relogio.Size = new System.Drawing.Size(23, 26);
            this.lbl_Relogio.TabIndex = 24;
            this.lbl_Relogio.Text = "0";
            // 
            // lbl_Cronometro
            // 
            this.lbl_Cronometro.AutoSize = true;
            this.lbl_Cronometro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Cronometro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cronometro.Location = new System.Drawing.Point(152, 136);
            this.lbl_Cronometro.Name = "lbl_Cronometro";
            this.lbl_Cronometro.Size = new System.Drawing.Size(23, 26);
            this.lbl_Cronometro.TabIndex = 23;
            this.lbl_Cronometro.Text = "0";
            // 
            // Timer2
            // 
            this.Timer2.Interval = 500;
            this.Timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(24, 136);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(120, 24);
            this.Label2.TabIndex = 18;
            this.Label2.Text = "Cron�metro";
            // 
            // lbl_Letreiro
            // 
            this.lbl_Letreiro.AutoSize = true;
            this.lbl_Letreiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Letreiro.Location = new System.Drawing.Point(12, 20);
            this.lbl_Letreiro.Name = "lbl_Letreiro";
            this.lbl_Letreiro.Size = new System.Drawing.Size(487, 24);
            this.lbl_Letreiro.TabIndex = 17;
            this.lbl_Letreiro.Text = "Disciplina: Linguagem de Programa��o Comercial I";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(546, 24);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.addToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.closeToolStripMenuItem.Text = "Close";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newProjectToolStripMenuItem,
            this.xxxxxToolStripMenuItem});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.addToolStripMenuItem.Text = "Add";
            // 
            // newProjectToolStripMenuItem
            // 
            this.newProjectToolStripMenuItem.Name = "newProjectToolStripMenuItem";
            this.newProjectToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.newProjectToolStripMenuItem.Text = "New Project";
            // 
            // xxxxxToolStripMenuItem
            // 
            this.xxxxxToolStripMenuItem.Name = "xxxxxToolStripMenuItem";
            this.xxxxxToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.xxxxxToolStripMenuItem.Text = "xxxxx";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // frm_Timer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 277);
            this.Controls.Add(this.CheckBox2);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.CheckBox3);
            this.Controls.Add(this.CheckBox1);
            this.Controls.Add(this.lbl_Relogio);
            this.Controls.Add(this.lbl_Cronometro);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.lbl_Letreiro);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm_Timer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_Timer";
            this.Load += new System.EventHandler(this.Frm_Timer_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.CheckBox CheckBox2;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Timer Timer3;
        internal System.Windows.Forms.CheckBox CheckBox3;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.Label lbl_Relogio;
        internal System.Windows.Forms.Label lbl_Cronometro;
        internal System.Windows.Forms.Timer Timer2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label lbl_Letreiro;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xxxxxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.Timer timer4;
    }
}