namespace ControlesDiversos_csharp
{
    partial class frm_ScrollBar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_ProgressBar = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.ProgressBar1 = new System.Windows.Forms.ProgressBar();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.lbl_V_Resultado = new System.Windows.Forms.Label();
            this.lbl_H_Resultado = new System.Windows.Forms.Label();
            this.VScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.HScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_H_Resultado2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_ProgressBar
            // 
            this.lbl_ProgressBar.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_ProgressBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_ProgressBar.Location = new System.Drawing.Point(59, 294);
            this.lbl_ProgressBar.Name = "lbl_ProgressBar";
            this.lbl_ProgressBar.Size = new System.Drawing.Size(156, 20);
            this.lbl_ProgressBar.TabIndex = 29;
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(23, 234);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(240, 16);
            this.Label3.TabIndex = 28;
            this.Label3.Text = "Propriedades";
            // 
            // ProgressBar1
            // 
            this.ProgressBar1.Location = new System.Drawing.Point(23, 262);
            this.ProgressBar1.Name = "ProgressBar1";
            this.ProgressBar1.Size = new System.Drawing.Size(252, 28);
            this.ProgressBar1.Step = 20;
            this.ProgressBar1.TabIndex = 27;
            // 
            // CheckBox1
            // 
            this.CheckBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox1.Location = new System.Drawing.Point(55, 190);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(144, 28);
            this.CheckBox1.TabIndex = 26;
            this.CheckBox1.Text = "Liga Barra de Progress�o";
            this.CheckBox1.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // lbl_V_Resultado
            // 
            this.lbl_V_Resultado.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_V_Resultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_V_Resultado.Location = new System.Drawing.Point(95, 142);
            this.lbl_V_Resultado.Name = "lbl_V_Resultado";
            this.lbl_V_Resultado.Size = new System.Drawing.Size(156, 20);
            this.lbl_V_Resultado.TabIndex = 25;
            // 
            // lbl_H_Resultado
            // 
            this.lbl_H_Resultado.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_H_Resultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_H_Resultado.Location = new System.Drawing.Point(27, 78);
            this.lbl_H_Resultado.Name = "lbl_H_Resultado";
            this.lbl_H_Resultado.Size = new System.Drawing.Size(156, 20);
            this.lbl_H_Resultado.TabIndex = 24;
            // 
            // VScrollBar1
            // 
            this.VScrollBar1.Location = new System.Drawing.Point(259, 22);
            this.VScrollBar1.Maximum = 1000;
            this.VScrollBar1.Minimum = 500;
            this.VScrollBar1.Name = "VScrollBar1";
            this.VScrollBar1.Size = new System.Drawing.Size(20, 152);
            this.VScrollBar1.TabIndex = 23;
            this.VScrollBar1.Value = 500;
            this.VScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.VScrollBar1_Scroll);
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(123, 118);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(124, 20);
            this.Label2.TabIndex = 22;
            this.Label2.Text = "VScrollBar";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(43, 22);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(136, 20);
            this.Label1.TabIndex = 21;
            this.Label1.Text = "HScrollBar";
            // 
            // HScrollBar1
            // 
            this.HScrollBar1.Location = new System.Drawing.Point(23, 54);
            this.HScrollBar1.Name = "HScrollBar1";
            this.HScrollBar1.Size = new System.Drawing.Size(164, 16);
            this.HScrollBar1.TabIndex = 20;
            this.HScrollBar1.ValueChanged += new System.EventHandler(this.HScrollBar1_ValueChanged);
            this.HScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.HScrollBar1_Scroll);
            // 
            // Timer1
            // 
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lbl_H_Resultado2
            // 
            this.lbl_H_Resultado2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_H_Resultado2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_H_Resultado2.Location = new System.Drawing.Point(27, 98);
            this.lbl_H_Resultado2.Name = "lbl_H_Resultado2";
            this.lbl_H_Resultado2.Size = new System.Drawing.Size(156, 20);
            this.lbl_H_Resultado2.TabIndex = 30;
            // 
            // frm_ScrollBar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 372);
            this.Controls.Add(this.lbl_H_Resultado2);
            this.Controls.Add(this.lbl_ProgressBar);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.ProgressBar1);
            this.Controls.Add(this.CheckBox1);
            this.Controls.Add(this.lbl_V_Resultado);
            this.Controls.Add(this.lbl_H_Resultado);
            this.Controls.Add(this.VScrollBar1);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.HScrollBar1);
            this.Name = "frm_ScrollBar";
            this.Text = "ScrollBar & ProgressBar";
            this.Load += new System.EventHandler(this.frm_ScrollBar_Load);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label lbl_ProgressBar;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.ProgressBar ProgressBar1;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.Label lbl_V_Resultado;
        internal System.Windows.Forms.Label lbl_H_Resultado;
        internal System.Windows.Forms.VScrollBar VScrollBar1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.HScrollBar HScrollBar1;
        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.Label lbl_H_Resultado2;
    }
}