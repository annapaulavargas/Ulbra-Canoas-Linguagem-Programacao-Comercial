namespace ControlesDiversos_csharp
{
    partial class frm_ListBox_ComboBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.ComboBox2 = new System.Windows.Forms.ComboBox();
            this.Btn_Add2 = new System.Windows.Forms.Button();
            this.Btn_Add3 = new System.Windows.Forms.Button();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.ComboBox3 = new System.Windows.Forms.ComboBox();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.btn_Volta = new System.Windows.Forms.Button();
            this.btn_Vai = new System.Windows.Forms.Button();
            this.ltb_Frutas2 = new System.Windows.Forms.ListBox();
            this.ltb_Frutas1 = new System.Windows.Forms.ListBox();
            this.txt_Fruta = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.ltb_Frutas3 = new System.Windows.Forms.ListBox();
            this.btn_Del = new System.Windows.Forms.Button();
            this.ltb_Frutas4 = new System.Windows.Forms.ListBox();
            this.btn_Del_ltb4 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xx1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xx2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label5.Location = new System.Drawing.Point(346, 308);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(13, 13);
            this.Label5.TabIndex = 51;
            this.Label5.Text = "0";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label6.Location = new System.Drawing.Point(346, 263);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(13, 13);
            this.Label6.TabIndex = 50;
            this.Label6.Text = "0";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label3.Location = new System.Drawing.Point(182, 308);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(13, 13);
            this.Label3.TabIndex = 49;
            this.Label3.Text = "0";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label4.Location = new System.Drawing.Point(182, 263);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(13, 13);
            this.Label4.TabIndex = 48;
            this.Label4.Text = "0";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label2.Location = new System.Drawing.Point(18, 308);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(13, 13);
            this.Label2.TabIndex = 47;
            this.Label2.Text = "0";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Label1.Location = new System.Drawing.Point(18, 263);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(13, 13);
            this.Label1.TabIndex = 46;
            this.Label1.Text = "0";
            // 
            // ComboBox2
            // 
            this.ComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.ComboBox2.Location = new System.Drawing.Point(170, 223);
            this.ComboBox2.Name = "ComboBox2";
            this.ComboBox2.Size = new System.Drawing.Size(136, 21);
            this.ComboBox2.TabIndex = 45;
            this.ComboBox2.SelectedIndexChanged += new System.EventHandler(this.ComboBox2_SelectedIndexChanged);
            // 
            // Btn_Add2
            // 
            this.Btn_Add2.Location = new System.Drawing.Point(185, 183);
            this.Btn_Add2.Name = "Btn_Add2";
            this.Btn_Add2.Size = new System.Drawing.Size(52, 28);
            this.Btn_Add2.TabIndex = 44;
            this.Btn_Add2.Text = "Add";
            this.Btn_Add2.Click += new System.EventHandler(this.Btn_Add2_Click);
            // 
            // Btn_Add3
            // 
            this.Btn_Add3.Location = new System.Drawing.Point(343, 183);
            this.Btn_Add3.Name = "Btn_Add3";
            this.Btn_Add3.Size = new System.Drawing.Size(52, 28);
            this.Btn_Add3.TabIndex = 43;
            this.Btn_Add3.Text = "Add";
            this.Btn_Add3.Click += new System.EventHandler(this.Btn_Add3_Click);
            // 
            // Btn_Add
            // 
            this.Btn_Add.Location = new System.Drawing.Point(42, 183);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(52, 28);
            this.Btn_Add.TabIndex = 42;
            this.Btn_Add.Text = "Add";
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // ComboBox3
            // 
            this.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox3.Location = new System.Drawing.Point(324, 223);
            this.ComboBox3.Name = "ComboBox3";
            this.ComboBox3.Size = new System.Drawing.Size(132, 21);
            this.ComboBox3.TabIndex = 41;
            this.ComboBox3.SelectedIndexChanged += new System.EventHandler(this.ComboBox3_SelectedIndexChanged);
            // 
            // ComboBox1
            // 
            this.ComboBox1.Location = new System.Drawing.Point(14, 223);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(140, 21);
            this.ComboBox1.TabIndex = 40;
            this.ComboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // btn_Volta
            // 
            this.btn_Volta.Location = new System.Drawing.Point(185, 123);
            this.btn_Volta.Name = "btn_Volta";
            this.btn_Volta.Size = new System.Drawing.Size(40, 28);
            this.btn_Volta.TabIndex = 39;
            this.btn_Volta.Text = "<<";
            this.btn_Volta.Click += new System.EventHandler(this.btn_Volta_Click);
            // 
            // btn_Vai
            // 
            this.btn_Vai.Location = new System.Drawing.Point(185, 75);
            this.btn_Vai.Name = "btn_Vai";
            this.btn_Vai.Size = new System.Drawing.Size(40, 28);
            this.btn_Vai.TabIndex = 38;
            this.btn_Vai.Text = ">>";
            this.btn_Vai.Click += new System.EventHandler(this.btn_Vai_Click);
            // 
            // ltb_Frutas2
            // 
            this.ltb_Frutas2.Location = new System.Drawing.Point(290, 71);
            this.ltb_Frutas2.Name = "ltb_Frutas2";
            this.ltb_Frutas2.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.ltb_Frutas2.Size = new System.Drawing.Size(105, 95);
            this.ltb_Frutas2.TabIndex = 37;
            // 
            // ltb_Frutas1
            // 
            this.ltb_Frutas1.Items.AddRange(new object[] {
            "Abacaxi",
            "Acerola",
            "Ameixa",
            "Banana",
            "Bergamota",
            "Cereja",
            "Laranja",
            "Lim�o",
            "Ma�a",
            "Manga",
            "Melancia",
            "Mel�o",
            "P�ssego",
            "Uva"});
            this.ltb_Frutas1.Location = new System.Drawing.Point(44, 68);
            this.ltb_Frutas1.Name = "ltb_Frutas1";
            this.ltb_Frutas1.Size = new System.Drawing.Size(110, 108);
            this.ltb_Frutas1.Sorted = true;
            this.ltb_Frutas1.TabIndex = 36;
            // 
            // txt_Fruta
            // 
            this.txt_Fruta.Location = new System.Drawing.Point(21, 42);
            this.txt_Fruta.Name = "txt_Fruta";
            this.txt_Fruta.Size = new System.Drawing.Size(100, 20);
            this.txt_Fruta.TabIndex = 52;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(139, 40);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(38, 23);
            this.button1.TabIndex = 53;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ltb_Frutas3
            // 
            this.ltb_Frutas3.FormattingEnabled = true;
            this.ltb_Frutas3.Location = new System.Drawing.Point(504, 71);
            this.ltb_Frutas3.Name = "ltb_Frutas3";
            this.ltb_Frutas3.Size = new System.Drawing.Size(114, 108);
            this.ltb_Frutas3.TabIndex = 54;
            // 
            // btn_Del
            // 
            this.btn_Del.Location = new System.Drawing.Point(517, 188);
            this.btn_Del.Name = "btn_Del";
            this.btn_Del.Size = new System.Drawing.Size(75, 23);
            this.btn_Del.TabIndex = 55;
            this.btn_Del.Text = "Del";
            this.btn_Del.UseVisualStyleBackColor = true;
            this.btn_Del.Click += new System.EventHandler(this.btn_Del_Click);
            // 
            // ltb_Frutas4
            // 
            this.ltb_Frutas4.FormattingEnabled = true;
            this.ltb_Frutas4.Location = new System.Drawing.Point(669, 71);
            this.ltb_Frutas4.Name = "ltb_Frutas4";
            this.ltb_Frutas4.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.ltb_Frutas4.Size = new System.Drawing.Size(112, 108);
            this.ltb_Frutas4.TabIndex = 56;
            // 
            // btn_Del_ltb4
            // 
            this.btn_Del_ltb4.Location = new System.Drawing.Point(701, 192);
            this.btn_Del_ltb4.Name = "btn_Del_ltb4";
            this.btn_Del_ltb4.Size = new System.Drawing.Size(68, 19);
            this.btn_Del_ltb4.TabIndex = 57;
            this.btn_Del_ltb4.Text = "Del";
            this.btn_Del_ltb4.UseVisualStyleBackColor = true;
            this.btn_Del_ltb4.Click += new System.EventHandler(this.btn_Del_ltb4_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.projectToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(960, 24);
            this.menuStrip1.TabIndex = 58;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripMenuItem1,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // projectToolStripMenuItem
            // 
            this.projectToolStripMenuItem.Name = "projectToolStripMenuItem";
            this.projectToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.projectToolStripMenuItem.Text = "Project";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x1ToolStripMenuItem,
            this.x2ToolStripMenuItem,
            this.x3ToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openToolStripMenuItem.Text = "&Open";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Checked = true;
            this.saveToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(149, 6);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.closeToolStripMenuItem.Text = "Close";
            // 
            // x1ToolStripMenuItem
            // 
            this.x1ToolStripMenuItem.Name = "x1ToolStripMenuItem";
            this.x1ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.x1ToolStripMenuItem.Text = "x1";
            // 
            // x2ToolStripMenuItem
            // 
            this.x2ToolStripMenuItem.Checked = true;
            this.x2ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.x2ToolStripMenuItem.Name = "x2ToolStripMenuItem";
            this.x2ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.x2ToolStripMenuItem.Text = "x2";
            // 
            // x3ToolStripMenuItem
            // 
            this.x3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xx1ToolStripMenuItem,
            this.xx2ToolStripMenuItem});
            this.x3ToolStripMenuItem.Name = "x3ToolStripMenuItem";
            this.x3ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.x3ToolStripMenuItem.Text = "x3";
            // 
            // xx1ToolStripMenuItem
            // 
            this.xx1ToolStripMenuItem.Name = "xx1ToolStripMenuItem";
            this.xx1ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.xx1ToolStripMenuItem.Text = "xx1";
            // 
            // xx2ToolStripMenuItem
            // 
            this.xx2ToolStripMenuItem.Name = "xx2ToolStripMenuItem";
            this.xx2ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.xx2ToolStripMenuItem.Text = "xx2";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            // 
            // frm_ListBox_ComboBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 331);
            this.Controls.Add(this.btn_Del_ltb4);
            this.Controls.Add(this.ltb_Frutas4);
            this.Controls.Add(this.btn_Del);
            this.Controls.Add(this.ltb_Frutas3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_Fruta);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.ComboBox2);
            this.Controls.Add(this.Btn_Add2);
            this.Controls.Add(this.Btn_Add3);
            this.Controls.Add(this.Btn_Add);
            this.Controls.Add(this.ComboBox3);
            this.Controls.Add(this.ComboBox1);
            this.Controls.Add(this.btn_Volta);
            this.Controls.Add(this.btn_Vai);
            this.Controls.Add(this.ltb_Frutas2);
            this.Controls.Add(this.ltb_Frutas1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm_ListBox_ComboBox";
            this.Text = "Frm_ListBox_ComboBox";
            this.Load += new System.EventHandler(this.frm_ListBox_ComboBox_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox ComboBox2;
        internal System.Windows.Forms.Button Btn_Add2;
        internal System.Windows.Forms.Button Btn_Add3;
        internal System.Windows.Forms.Button Btn_Add;
        internal System.Windows.Forms.ComboBox ComboBox3;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.Button btn_Volta;
        internal System.Windows.Forms.Button btn_Vai;
        internal System.Windows.Forms.ListBox ltb_Frutas2;
        internal System.Windows.Forms.ListBox ltb_Frutas1;
        private System.Windows.Forms.TextBox txt_Fruta;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox ltb_Frutas3;
        private System.Windows.Forms.Button btn_Del;
        private System.Windows.Forms.ListBox ltb_Frutas4;
        private System.Windows.Forms.Button btn_Del_ltb4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xx1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xx2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
    }
}