using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_RadioButton : Form
    {
        public frm_RadioButton()
        {
            InitializeComponent();
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton1.Checked =" + RadioButton1.Checked;
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton2.Checked =" + RadioButton2.Checked;
        }

        private void RadioButton8_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton8.Checked =" + RadioButton8.Checked;
            GroupBox2.Enabled = false;
        }

        private void RadioButton7_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton7.Checked =" + RadioButton7.Checked;
            GroupBox2.Enabled = true;
        }

        private void RadioButton6_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton6.Checked =" + RadioButton6.Checked;
        }

        private void RadioButton5_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton5.Checked =" + RadioButton5.Checked;
        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton3.Checked =" + RadioButton3.Checked;
        }

        private void RadioButton4_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton4.Checked =" + RadioButton4.Checked;
        }

        private void GroupBox2_Enter(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "RadioButton2.Checked =" + RadioButton2.Checked;
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}