namespace ControlesDiversos_csharp
{
    partial class frm_Dialogs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ColorDialog = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.btn_FontDialog = new System.Windows.Forms.Button();
            this.btn_OpenFileDialog = new System.Windows.Forms.Button();
            this.btn_SaveFileDialog = new System.Windows.Forms.Button();
            this.btn_FolderBrowserDialog = new System.Windows.Forms.Button();
            this.RichTextBox1 = new System.Windows.Forms.RichTextBox();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.SuspendLayout();
            // 
            // btn_ColorDialog
            // 
            this.btn_ColorDialog.Location = new System.Drawing.Point(272, 14);
            this.btn_ColorDialog.Name = "btn_ColorDialog";
            this.btn_ColorDialog.Size = new System.Drawing.Size(103, 25);
            this.btn_ColorDialog.TabIndex = 0;
            this.btn_ColorDialog.Text = "ColorDialog";
            this.btn_ColorDialog.UseVisualStyleBackColor = true;
            this.btn_ColorDialog.Click += new System.EventHandler(this.btn_ColorDialog_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btn_FontDialog
            // 
            this.btn_FontDialog.Location = new System.Drawing.Point(272, 45);
            this.btn_FontDialog.Name = "btn_FontDialog";
            this.btn_FontDialog.Size = new System.Drawing.Size(103, 25);
            this.btn_FontDialog.TabIndex = 1;
            this.btn_FontDialog.Text = "FontDialog";
            this.btn_FontDialog.UseVisualStyleBackColor = true;
            this.btn_FontDialog.Click += new System.EventHandler(this.btn_FontDialog_Click);
            // 
            // btn_OpenFileDialog
            // 
            this.btn_OpenFileDialog.Location = new System.Drawing.Point(12, 14);
            this.btn_OpenFileDialog.Name = "btn_OpenFileDialog";
            this.btn_OpenFileDialog.Size = new System.Drawing.Size(103, 25);
            this.btn_OpenFileDialog.TabIndex = 2;
            this.btn_OpenFileDialog.Text = "OpenFileDialog";
            this.btn_OpenFileDialog.UseVisualStyleBackColor = true;
            this.btn_OpenFileDialog.Click += new System.EventHandler(this.btn_OpenFileDialog_Click);
            // 
            // btn_SaveFileDialog
            // 
            this.btn_SaveFileDialog.Location = new System.Drawing.Point(12, 45);
            this.btn_SaveFileDialog.Name = "btn_SaveFileDialog";
            this.btn_SaveFileDialog.Size = new System.Drawing.Size(103, 25);
            this.btn_SaveFileDialog.TabIndex = 3;
            this.btn_SaveFileDialog.Text = "SaveFileDialog";
            this.btn_SaveFileDialog.UseVisualStyleBackColor = true;
            this.btn_SaveFileDialog.Click += new System.EventHandler(this.btn_SaveFileDialog_Click);
            // 
            // btn_FolderBrowserDialog
            // 
            this.btn_FolderBrowserDialog.Location = new System.Drawing.Point(134, 14);
            this.btn_FolderBrowserDialog.Name = "btn_FolderBrowserDialog";
            this.btn_FolderBrowserDialog.Size = new System.Drawing.Size(103, 25);
            this.btn_FolderBrowserDialog.TabIndex = 4;
            this.btn_FolderBrowserDialog.Text = "FolderBrowserDialog";
            this.btn_FolderBrowserDialog.UseVisualStyleBackColor = true;
            this.btn_FolderBrowserDialog.Click += new System.EventHandler(this.btn_FolderBrowserDialog_Click);
            // 
            // RichTextBox1
            // 
            this.RichTextBox1.Location = new System.Drawing.Point(12, 76);
            this.RichTextBox1.Name = "RichTextBox1";
            this.RichTextBox1.Size = new System.Drawing.Size(469, 202);
            this.RichTextBox1.TabIndex = 8;
            this.RichTextBox1.Text = "RichTextBox1";
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // frm_Dialogs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 290);
            this.Controls.Add(this.RichTextBox1);
            this.Controls.Add(this.btn_FolderBrowserDialog);
            this.Controls.Add(this.btn_SaveFileDialog);
            this.Controls.Add(this.btn_OpenFileDialog);
            this.Controls.Add(this.btn_FontDialog);
            this.Controls.Add(this.btn_ColorDialog);
            this.Name = "frm_Dialogs";
            this.Text = "frm_Dialogs";
            this.Load += new System.EventHandler(this.frm_Dialogs_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_ColorDialog;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button btn_FontDialog;
        private System.Windows.Forms.Button btn_OpenFileDialog;
        private System.Windows.Forms.Button btn_SaveFileDialog;
        private System.Windows.Forms.Button btn_FolderBrowserDialog;
        internal System.Windows.Forms.RichTextBox RichTextBox1;
        private System.Windows.Forms.PrintDialog printDialog1;
    }
}