using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_Timer : Form
    {
            private DateTime Cronometro;

        public frm_Timer()
        {
            InitializeComponent();
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox1.CheckState == CheckState.Checked) 
            {
                Timer1.Enabled = true;
                CheckBox1.Text = "Para Letreiro";
            }
            else
            {
                Timer1.Enabled = false;
                CheckBox1.Text = "Liga Letreiro";
            }
        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox2.CheckState == CheckState.Checked)
            {
                Timer2.Enabled = true;
                CheckBox2.Text = "Para Cron�metro";
            }
            else
            {
                Timer2.Enabled = false;
                CheckBox2.Text = "Liga Cron�metro";
            }
        }

        private void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox3.CheckState == CheckState.Checked)
            {
                Timer3.Enabled = true;
                CheckBox3.Text = "Para Rel�gio";
            }
            else
            {
                Timer3.Enabled = false;
                CheckBox3.Text = "Liga Rel�gio";
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            //Letreiro
            if (lbl_Letreiro.Location.X < (-1 * lbl_Letreiro.Width))
            {
                lbl_Letreiro.Left = this.Width;
            }
            else
            {
                lbl_Letreiro.Left = lbl_Letreiro.Left - 20;
            }
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            //Cronometro
            Cronometro = Cronometro.AddMilliseconds(Timer2.Interval);
            lbl_Cronometro.Text = Cronometro.Hour + ":" + Cronometro.Minute + ":" + Cronometro.Second + ":" + Cronometro.Millisecond;
        }
        private void Timer3_Tick(object sender, EventArgs e)
        {
            //Relogio
            lbl_Relogio.Text = DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second + ":" + DateTime.Now.Millisecond;
        }
        

        private void Frm_Timer_Load(object sender, EventArgs e)
        {
            Cronometro = Convert.ToDateTime ("00:00:00");
            // ou
            Cronometro = DateTime.Parse("00:00:00");

        }

    }
}