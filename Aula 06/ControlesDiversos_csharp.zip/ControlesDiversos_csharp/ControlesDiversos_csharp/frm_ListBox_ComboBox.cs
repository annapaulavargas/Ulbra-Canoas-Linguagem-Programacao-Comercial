using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_ListBox_ComboBox : Form
    {
        public frm_ListBox_ComboBox()
        {
            InitializeComponent();
        }


        private void btn_Vai_Click(object sender, EventArgs e)
        {
            int i;
            for (i=0; i<ltb_Frutas1.SelectedItems.Count ; i++)
            {
                ltb_Frutas2.Items.Add(ltb_Frutas1.SelectedItems[i]);
                ltb_Frutas3.Items.Insert (0,ltb_Frutas1.SelectedItems[i]);
                ltb_Frutas4.Items.Add(ltb_Frutas1.SelectedItems[i]);
            }
            ltb_Frutas1.Items.Remove(ltb_Frutas1.SelectedItem);

        }

        private void btn_Volta_Click(object sender, EventArgs e)
        {
            int i;
            try
            {
            //<C�digos que podem gerar erro>
                for (i=0; i<=(ltb_Frutas2.SelectedItems.Count-1) ; i++)
                {
                    ltb_Frutas1.Items.Add(ltb_Frutas2.SelectedItems[i]);
                }
                Console.WriteLine("ltb_Frutas2.Items.Count = {0}", ltb_Frutas2.Items.Count);
                Console.WriteLine("ltb_Frutas2.SelectedItems.Count = {0}", ltb_Frutas2.SelectedItems.Count);
                for (i = (ltb_Frutas2.SelectedIndices.Count - 1); i>=0; i--)
                {
                    ltb_Frutas2.Items.Remove(ltb_Frutas2.SelectedItems[i]);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show (Ex.Message);
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label1.Text = "ComboBox1.SelectedIndex = " + ComboBox1.SelectedIndex;
            Label2.Text = "ComboBox1.Text = " + ComboBox1.Text;
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label3.Text = "ComboBox2.SelectedIndex = " + ComboBox2.SelectedIndex;
            Label4.Text = "ComboBox2.Text = " + ComboBox2.Text;
        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label5.Text = "ComboBox3.SelectedIndex = " + Convert.ToString (ComboBox3.SelectedIndex);
            Label6.Text = "ComboBox3.Text = " + ComboBox3.Text;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            int i;

            for (i = 0; i < ltb_Frutas1.SelectedItems.Count; i++)
            {
                ComboBox1.Items.Add(ltb_Frutas1.SelectedItems[i]);
            }
        }

        private void Btn_Add2_Click(object sender, EventArgs e)
        {
            int i;

            for (i = 0; i < ltb_Frutas1.SelectedItems.Count; i++)
            {
                ComboBox2.Items.Add(ltb_Frutas1.SelectedItems[i]);
            }
        }

        private void Btn_Add3_Click(object sender, EventArgs e)
        {
            int i;

            for (i = 0; i < ltb_Frutas2.SelectedItems.Count; i++)
            {
                ComboBox3.Items.Add(ltb_Frutas2.SelectedItems[i]);
            }
        }

        private void frm_ListBox_ComboBox_Load(object sender, EventArgs e)
        {
            ltb_Frutas1.Items.Add("Jaca");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_Fruta.Text.Length > 0)
            {
                ltb_Frutas1.Items.Add(txt_Fruta .Text );
            }
        }

        private void btn_Del_Click(object sender, EventArgs e)
        {
            if (ltb_Frutas3.SelectedIndex >= 0)
            {
                ltb_Frutas3.Items.RemoveAt(ltb_Frutas3.SelectedIndex);
            }
        }


        private void btn_Del_ltb4_Click(object sender, EventArgs e)
        {
            int i;
            try
            {
                for (i = 0; i < ltb_Frutas4.SelectedIndices.Count ; i++)
                {
                    ltb_Frutas4.Items.Remove(ltb_Frutas4.SelectedItems[i]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

    }
}