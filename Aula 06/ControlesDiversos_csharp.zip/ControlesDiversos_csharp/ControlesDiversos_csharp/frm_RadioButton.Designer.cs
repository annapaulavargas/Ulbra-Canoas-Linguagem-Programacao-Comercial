namespace ControlesDiversos_csharp
{
    partial class frm_RadioButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_RadioButton));
            this.Label2 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.RadioButton7 = new System.Windows.Forms.RadioButton();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.op��o1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.op��o2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xxxxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yyyyyyyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.xxxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RadioButton8 = new System.Windows.Forms.RadioButton();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.ContextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ContextMenuStrip_opcao1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip_opcao2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip_opcao3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.ContextMenuStrip_opcao4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip_Sair = new System.Windows.Forms.ToolStripMenuItem();
            this.RadioButton5 = new System.Windows.Forms.RadioButton();
            this.RadioButton6 = new System.Windows.Forms.RadioButton();
            this.lbl_Resultado = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.RadioButton2 = new System.Windows.Forms.RadioButton();
            this.RadioButton1 = new System.Windows.Forms.RadioButton();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.RadioButton4 = new System.Windows.Forms.RadioButton();
            this.RadioButton3 = new System.Windows.Forms.RadioButton();
            this.Label1 = new System.Windows.Forms.Label();
            this.Panel2.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.ContextMenuStrip1.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(48, 257);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(352, 20);
            this.Label2.TabIndex = 23;
            this.Label2.Text = "Pane e GrouBox: Verificar a exist�ncia da Propriedade AutoScroll";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(220, 25);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(182, 13);
            this.Label3.TabIndex = 22;
            this.Label3.Text = "RadioButton: Appearance e FlatStyle";
            // 
            // Panel2
            // 
            this.Panel2.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel2.Controls.Add(this.RadioButton7);
            this.Panel2.Controls.Add(this.RadioButton8);
            this.Panel2.Location = new System.Drawing.Point(228, 55);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(172, 88);
            this.Panel2.TabIndex = 20;
            // 
            // RadioButton7
            // 
            this.RadioButton7.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton7.ContextMenuStrip = this.contextMenuStrip2;
            this.RadioButton7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RadioButton7.Image = ((System.Drawing.Image)(resources.GetObject("RadioButton7.Image")));
            this.RadioButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.RadioButton7.Location = new System.Drawing.Point(20, 48);
            this.RadioButton7.Name = "RadioButton7";
            this.RadioButton7.Size = new System.Drawing.Size(136, 28);
            this.RadioButton7.TabIndex = 6;
            this.RadioButton7.Text = "RadioButton7";
            this.RadioButton7.CheckedChanged += new System.EventHandler(this.RadioButton7_CheckedChanged);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.op��o1ToolStripMenuItem,
            this.op��o2ToolStripMenuItem,
            this.toolStripMenuItem3,
            this.xxxToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(117, 76);
            // 
            // op��o1ToolStripMenuItem
            // 
            this.op��o1ToolStripMenuItem.Name = "op��o1ToolStripMenuItem";
            this.op��o1ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.op��o1ToolStripMenuItem.Text = "op��o 1";
            // 
            // op��o2ToolStripMenuItem
            // 
            this.op��o2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xxxxToolStripMenuItem,
            this.yyyyyyyToolStripMenuItem});
            this.op��o2ToolStripMenuItem.Name = "op��o2ToolStripMenuItem";
            this.op��o2ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.op��o2ToolStripMenuItem.Text = "op��o 2";
            // 
            // xxxxToolStripMenuItem
            // 
            this.xxxxToolStripMenuItem.Name = "xxxxToolStripMenuItem";
            this.xxxxToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.xxxxToolStripMenuItem.Text = "xxxx";
            // 
            // yyyyyyyToolStripMenuItem
            // 
            this.yyyyyyyToolStripMenuItem.Name = "yyyyyyyToolStripMenuItem";
            this.yyyyyyyToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.yyyyyyyToolStripMenuItem.Text = "yyyyyyy";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(113, 6);
            // 
            // xxxToolStripMenuItem
            // 
            this.xxxToolStripMenuItem.Name = "xxxToolStripMenuItem";
            this.xxxToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.xxxToolStripMenuItem.Text = "xxx";
            // 
            // RadioButton8
            // 
            this.RadioButton8.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RadioButton8.Image = ((System.Drawing.Image)(resources.GetObject("RadioButton8.Image")));
            this.RadioButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.RadioButton8.Location = new System.Drawing.Point(20, 10);
            this.RadioButton8.Name = "RadioButton8";
            this.RadioButton8.Size = new System.Drawing.Size(140, 28);
            this.RadioButton8.TabIndex = 7;
            this.RadioButton8.Text = "RadioButton8";
            this.RadioButton8.CheckedChanged += new System.EventHandler(this.RadioButton8_CheckedChanged);
            // 
            // GroupBox2
            // 
            this.GroupBox2.ContextMenuStrip = this.ContextMenuStrip1;
            this.GroupBox2.Controls.Add(this.RadioButton5);
            this.GroupBox2.Controls.Add(this.RadioButton6);
            this.GroupBox2.Location = new System.Drawing.Point(228, 149);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(172, 105);
            this.GroupBox2.TabIndex = 21;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "GroupBox2";
            this.GroupBox2.Enter += new System.EventHandler(this.GroupBox2_Enter);
            // 
            // ContextMenuStrip1
            // 
            this.ContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContextMenuStrip_opcao1,
            this.ContextMenuStrip_opcao2,
            this.ContextMenuStrip_opcao3,
            this.ToolStripMenuItem1,
            this.ContextMenuStrip_opcao4,
            this.ContextMenuStrip_Sair});
            this.ContextMenuStrip1.Name = "ContextMenuStrip1";
            this.ContextMenuStrip1.Size = new System.Drawing.Size(119, 120);
            // 
            // ContextMenuStrip_opcao1
            // 
            this.ContextMenuStrip_opcao1.Name = "ContextMenuStrip_opcao1";
            this.ContextMenuStrip_opcao1.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao1.Text = "Op��o 1";
            // 
            // ContextMenuStrip_opcao2
            // 
            this.ContextMenuStrip_opcao2.Name = "ContextMenuStrip_opcao2";
            this.ContextMenuStrip_opcao2.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao2.Text = "Op��o 2";
            // 
            // ContextMenuStrip_opcao3
            // 
            this.ContextMenuStrip_opcao3.Name = "ContextMenuStrip_opcao3";
            this.ContextMenuStrip_opcao3.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao3.Text = "Op��o 3";
            // 
            // ToolStripMenuItem1
            // 
            this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            this.ToolStripMenuItem1.Size = new System.Drawing.Size(115, 6);
            // 
            // ContextMenuStrip_opcao4
            // 
            this.ContextMenuStrip_opcao4.Name = "ContextMenuStrip_opcao4";
            this.ContextMenuStrip_opcao4.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao4.Text = "Op��o 4";
            // 
            // ContextMenuStrip_Sair
            // 
            this.ContextMenuStrip_Sair.Name = "ContextMenuStrip_Sair";
            this.ContextMenuStrip_Sair.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_Sair.Text = "Sair";
            // 
            // RadioButton5
            // 
            this.RadioButton5.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton5.ContextMenuStrip = this.contextMenuStrip2;
            this.RadioButton5.Image = ((System.Drawing.Image)(resources.GetObject("RadioButton5.Image")));
            this.RadioButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.RadioButton5.Location = new System.Drawing.Point(12, 60);
            this.RadioButton5.Name = "RadioButton5";
            this.RadioButton5.Size = new System.Drawing.Size(144, 24);
            this.RadioButton5.TabIndex = 4;
            this.RadioButton5.Text = "RadioButton5";
            this.RadioButton5.CheckedChanged += new System.EventHandler(this.RadioButton5_CheckedChanged);
            // 
            // RadioButton6
            // 
            this.RadioButton6.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton6.Image = ((System.Drawing.Image)(resources.GetObject("RadioButton6.Image")));
            this.RadioButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RadioButton6.Location = new System.Drawing.Point(12, 24);
            this.RadioButton6.Name = "RadioButton6";
            this.RadioButton6.Size = new System.Drawing.Size(140, 24);
            this.RadioButton6.TabIndex = 5;
            this.RadioButton6.Text = "RadioButton6";
            this.RadioButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton6.CheckedChanged += new System.EventHandler(this.RadioButton6_CheckedChanged);
            // 
            // lbl_Resultado
            // 
            this.lbl_Resultado.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbl_Resultado.Location = new System.Drawing.Point(132, 293);
            this.lbl_Resultado.Name = "lbl_Resultado";
            this.lbl_Resultado.Size = new System.Drawing.Size(196, 16);
            this.lbl_Resultado.TabIndex = 19;
            // 
            // Panel1
            // 
            this.Panel1.AutoScroll = true;
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Panel1.ContextMenuStrip = this.contextMenuStrip2;
            this.Panel1.Controls.Add(this.RadioButton2);
            this.Panel1.Controls.Add(this.RadioButton1);
            this.Panel1.Location = new System.Drawing.Point(31, 42);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(175, 101);
            this.Panel1.TabIndex = 16;
            // 
            // RadioButton2
            // 
            this.RadioButton2.Location = new System.Drawing.Point(12, 48);
            this.RadioButton2.Name = "RadioButton2";
            this.RadioButton2.Size = new System.Drawing.Size(136, 16);
            this.RadioButton2.TabIndex = 1;
            this.RadioButton2.Text = "RadioButton2";
            this.RadioButton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // RadioButton1
            // 
            this.RadioButton1.Checked = true;
            this.RadioButton1.ContextMenuStrip = this.ContextMenuStrip1;
            this.RadioButton1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.RadioButton1.Location = new System.Drawing.Point(12, 17);
            this.RadioButton1.Name = "RadioButton1";
            this.RadioButton1.Size = new System.Drawing.Size(140, 25);
            this.RadioButton1.TabIndex = 0;
            this.RadioButton1.TabStop = true;
            this.RadioButton1.Text = "RadioButton1";
            this.RadioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.RadioButton4);
            this.GroupBox1.Controls.Add(this.RadioButton3);
            this.GroupBox1.Location = new System.Drawing.Point(26, 145);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(180, 84);
            this.GroupBox1.TabIndex = 18;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "xxxxxx";
            // 
            // RadioButton4
            // 
            this.RadioButton4.Location = new System.Drawing.Point(16, 56);
            this.RadioButton4.Name = "RadioButton4";
            this.RadioButton4.Size = new System.Drawing.Size(144, 16);
            this.RadioButton4.TabIndex = 3;
            this.RadioButton4.Text = "RadioButton4";
            this.RadioButton4.CheckedChanged += new System.EventHandler(this.RadioButton4_CheckedChanged);
            // 
            // RadioButton3
            // 
            this.RadioButton3.Location = new System.Drawing.Point(16, 28);
            this.RadioButton3.Name = "RadioButton3";
            this.RadioButton3.Size = new System.Drawing.Size(140, 16);
            this.RadioButton3.TabIndex = 2;
            this.RadioButton3.Text = "RadioButton3";
            this.RadioButton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(23, 18);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(144, 20);
            this.Label1.TabIndex = 17;
            this.Label1.Text = "Panel: BorderStyle";
            this.Label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // frm_RadioButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 335);
            this.ContextMenuStrip = this.ContextMenuStrip1;
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.lbl_Resultado);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Label1);
            this.Name = "frm_RadioButton";
            this.Text = "RadioButton, Panel e GroupBox";
            this.Panel2.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.GroupBox2.ResumeLayout(false);
            this.ContextMenuStrip1.ResumeLayout(false);
            this.Panel1.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.RadioButton RadioButton7;
        internal System.Windows.Forms.RadioButton RadioButton8;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.RadioButton RadioButton5;
        internal System.Windows.Forms.RadioButton RadioButton6;
        internal System.Windows.Forms.Label lbl_Resultado;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.RadioButton RadioButton2;
        internal System.Windows.Forms.RadioButton RadioButton1;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.RadioButton RadioButton4;
        internal System.Windows.Forms.RadioButton RadioButton3;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ContextMenuStrip ContextMenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao1;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao2;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao3;
        internal System.Windows.Forms.ToolStripSeparator ToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao4;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_Sair;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem op��o1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem op��o2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xxxxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yyyyyyyToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem xxxToolStripMenuItem;
    }
}