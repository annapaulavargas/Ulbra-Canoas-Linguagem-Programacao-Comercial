using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_Dialogs : Form
    {
        public string Nome_arquivo = "";
        public string caminho = "";
        public frm_Dialogs()
        {
            InitializeComponent();
        }

        private void btn_OpenFileDialog_Click(object sender, EventArgs e)
        {
            //Indica a extensao default
            openFileDialog1.DefaultExt = "*.RTF";
            openFileDialog1.Filter = "Arquivos de Texto (*.rtf)|*.rtf";
            openFileDialog1.InitialDirectory = caminho;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //O m�todo LoadFile l� o arquivo e mostra-o no controle RichTextBox
                Nome_arquivo = openFileDialog1.FileName;
                this.Text = "Arquivo: " + Nome_arquivo;
                RichTextBox1.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.RichText);
            }

        }

        private void btn_SaveFileDialog_Click(object sender, EventArgs e)
        {
            saveFileDialog1.DefaultExt = "*.RTF";
            saveFileDialog1.Filter = "Arquivos de Texto (*.rtf)|*.rtf";
            if (Nome_arquivo.Length > 0)
            {
                saveFileDialog1.FileName = Nome_arquivo;
            }

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (saveFileDialog1.FileName.Length > 0)
                {
                    // Save the contents of the RichTextBox into the file.
                    RichTextBox1.SaveFile(saveFileDialog1.FileName, RichTextBoxStreamType.RichText);
                }
            }
        }

        private void btn_FontDialog_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
        }

        private void btn_ColorDialog_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            RichTextBox1.SelectionColor = colorDialog1.Color;
        }

        private void btn_FolderBrowserDialog_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.SelectedPath = caminho;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                caminho = folderBrowserDialog1.SelectedPath;
            }
        }

        private void frm_Dialogs_Load(object sender, EventArgs e)
        {
            caminho = Application.StartupPath;
        }

    }
}