namespace ControlesDiversos_csharp
{
    partial class frm_inicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_inicial));
            this.ImageList2 = new System.Windows.Forms.ImageList(this.components);
            this.ImageList1 = new System.Windows.Forms.ImageList(this.components);
            this.PrintDialog1 = new System.Windows.Forms.PrintDialog();
            this.ContextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ContextMenuStrip_opcao1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip_opcao2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip_opcao3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.ContextMenuStrip_opcao4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuStrip_Sair = new System.Windows.Forms.ToolStripMenuItem();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.Formul�riosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmCheck = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmRadio = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmTab = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmScroll = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmTimer = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmList = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmDialogs = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuFrmKeys = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.Menu_Sair = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.op��o1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.op��o2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xxxxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yyyyyyyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.xxxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Botao1 = new System.Windows.Forms.ToolStripButton();
            this.Botao2 = new System.Windows.Forms.ToolStripButton();
            this.Botao3 = new System.Windows.Forms.ToolStripButton();
            this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.Botao5 = new System.Windows.Forms.ToolStripButton();
            this.ToolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Painel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Painel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Painel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Painel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Painel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.teste2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ContextMenuStrip1.SuspendLayout();
            this.MenuStrip1.SuspendLayout();
            this.ToolStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.StatusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImageList2
            // 
            this.ImageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.ImageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.ImageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // ImageList1
            // 
            this.ImageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList1.ImageStream")));
            this.ImageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList1.Images.SetKeyName(0, "");
            this.ImageList1.Images.SetKeyName(1, "");
            this.ImageList1.Images.SetKeyName(2, "");
            this.ImageList1.Images.SetKeyName(3, "");
            this.ImageList1.Images.SetKeyName(4, "");
            // 
            // PrintDialog1
            // 
            this.PrintDialog1.UseEXDialog = true;
            // 
            // ContextMenuStrip1
            // 
            this.ContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContextMenuStrip_opcao1,
            this.ContextMenuStrip_opcao2,
            this.ContextMenuStrip_opcao3,
            this.ToolStripMenuItem1,
            this.ContextMenuStrip_opcao4,
            this.ContextMenuStrip_Sair});
            this.ContextMenuStrip1.Name = "ContextMenuStrip1";
            this.ContextMenuStrip1.Size = new System.Drawing.Size(119, 120);
            // 
            // ContextMenuStrip_opcao1
            // 
            this.ContextMenuStrip_opcao1.Name = "ContextMenuStrip_opcao1";
            this.ContextMenuStrip_opcao1.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao1.Text = "Op��o 1";
            this.ContextMenuStrip_opcao1.Click += new System.EventHandler(this.ContextMenuStrip_opcao1_Click);
            // 
            // ContextMenuStrip_opcao2
            // 
            this.ContextMenuStrip_opcao2.Name = "ContextMenuStrip_opcao2";
            this.ContextMenuStrip_opcao2.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao2.Text = "Op��o 2";
            this.ContextMenuStrip_opcao2.Click += new System.EventHandler(this.ContextMenuStrip_opcao2_Click);
            // 
            // ContextMenuStrip_opcao3
            // 
            this.ContextMenuStrip_opcao3.Name = "ContextMenuStrip_opcao3";
            this.ContextMenuStrip_opcao3.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao3.Text = "Op��o 3";
            this.ContextMenuStrip_opcao3.Click += new System.EventHandler(this.ContextMenuStrip_opcao3_Click);
            // 
            // ToolStripMenuItem1
            // 
            this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            this.ToolStripMenuItem1.Size = new System.Drawing.Size(115, 6);
            // 
            // ContextMenuStrip_opcao4
            // 
            this.ContextMenuStrip_opcao4.Name = "ContextMenuStrip_opcao4";
            this.ContextMenuStrip_opcao4.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_opcao4.Text = "Op��o 4";
            this.ContextMenuStrip_opcao4.Click += new System.EventHandler(this.ContextMenuStrip_opcao4_Click);
            // 
            // ContextMenuStrip_Sair
            // 
            this.ContextMenuStrip_Sair.Name = "ContextMenuStrip_Sair";
            this.ContextMenuStrip_Sair.Size = new System.Drawing.Size(118, 22);
            this.ContextMenuStrip_Sair.Text = "Sair";
            // 
            // Timer1
            // 
            this.Timer1.Enabled = true;
            this.Timer1.Interval = 500;
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // Formul�riosToolStripMenuItem
            // 
            this.Formul�riosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuFrmCheck,
            this.MenuFrmRadio,
            this.MenuFrmTab,
            this.MenuFrmScroll,
            this.MenuFrmTimer,
            this.MenuFrmList,
            this.MenuFrmDialogs,
            this.MenuFrmKeys,
            this.ToolStripMenuItem2,
            this.Menu_Sair});
            this.Formul�riosToolStripMenuItem.Name = "Formul�riosToolStripMenuItem";
            this.Formul�riosToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.Formul�riosToolStripMenuItem.Text = "Formul�rios";
            // 
            // MenuFrmCheck
            // 
            this.MenuFrmCheck.Name = "MenuFrmCheck";
            this.MenuFrmCheck.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmCheck.Text = "CheckBox, Panel";
            this.MenuFrmCheck.Click += new System.EventHandler(this.MenuFrmCheck_Click);
            // 
            // MenuFrmRadio
            // 
            this.MenuFrmRadio.Name = "MenuFrmRadio";
            this.MenuFrmRadio.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmRadio.Text = "RadioButton, Panel e GroupBox";
            this.MenuFrmRadio.Click += new System.EventHandler(this.MenuFrmRadio_Click);
            // 
            // MenuFrmTab
            // 
            this.MenuFrmTab.Name = "MenuFrmTab";
            this.MenuFrmTab.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmTab.Text = "TabControl, PictureBox, DateTimePicker, MonthCalendar, NumericUpDown e ";
            this.MenuFrmTab.Click += new System.EventHandler(this.MenuFrmTab_Click);
            // 
            // MenuFrmScroll
            // 
            this.MenuFrmScroll.Name = "MenuFrmScroll";
            this.MenuFrmScroll.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmScroll.Text = "ScrollBar, ProgressBar";
            this.MenuFrmScroll.Click += new System.EventHandler(this.MenuFrmScroll_Click);
            // 
            // MenuFrmTimer
            // 
            this.MenuFrmTimer.Name = "MenuFrmTimer";
            this.MenuFrmTimer.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmTimer.Text = "Timer";
            this.MenuFrmTimer.Click += new System.EventHandler(this.MenuFrmTimer_Click);
            // 
            // MenuFrmList
            // 
            this.MenuFrmList.Name = "MenuFrmList";
            this.MenuFrmList.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmList.Text = "ListBox, ComboBox";
            this.MenuFrmList.Click += new System.EventHandler(this.MenuFrmList_Click);
            // 
            // MenuFrmDialogs
            // 
            this.MenuFrmDialogs.Name = "MenuFrmDialogs";
            this.MenuFrmDialogs.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmDialogs.Text = "Dialogs";
            this.MenuFrmDialogs.Click += new System.EventHandler(this.MenuFrmDialogs_Click);
            // 
            // MenuFrmKeys
            // 
            this.MenuFrmKeys.Name = "MenuFrmKeys";
            this.MenuFrmKeys.Size = new System.Drawing.Size(484, 22);
            this.MenuFrmKeys.Text = "Keys";
            this.MenuFrmKeys.Click += new System.EventHandler(this.MenuFrmKeys_Click);
            // 
            // ToolStripMenuItem2
            // 
            this.ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            this.ToolStripMenuItem2.Size = new System.Drawing.Size(481, 6);
            // 
            // Menu_Sair
            // 
            this.Menu_Sair.Name = "Menu_Sair";
            this.Menu_Sair.Size = new System.Drawing.Size(484, 22);
            this.Menu_Sair.Text = "Sair";
            this.Menu_Sair.Click += new System.EventHandler(this.Menu_Sair_Click);
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Formul�riosToolStripMenuItem,
            this.teste2ToolStripMenuItem});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(700, 24);
            this.MenuStrip1.TabIndex = 4;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // ToolStrip1
            // 
            this.ToolStrip1.ContextMenuStrip = this.contextMenuStrip2;
            this.ToolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Botao1,
            this.Botao2,
            this.Botao3,
            this.ToolStripSeparator1,
            this.Botao5,
            this.ToolStripButton1,
            this.toolStripLabel1,
            this.toolStripSeparator2});
            this.ToolStrip1.Location = new System.Drawing.Point(0, 24);
            this.ToolStrip1.Name = "ToolStrip1";
            this.ToolStrip1.Size = new System.Drawing.Size(700, 39);
            this.ToolStrip1.TabIndex = 5;
            this.ToolStrip1.Text = "ToolStrip1";
            this.ToolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ToolStrip1_ItemClicked);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.op��o1ToolStripMenuItem,
            this.op��o2ToolStripMenuItem,
            this.toolStripMenuItem3,
            this.xxxToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(117, 76);
            // 
            // op��o1ToolStripMenuItem
            // 
            this.op��o1ToolStripMenuItem.Name = "op��o1ToolStripMenuItem";
            this.op��o1ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.op��o1ToolStripMenuItem.Text = "op��o 1";
            // 
            // op��o2ToolStripMenuItem
            // 
            this.op��o2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xxxxToolStripMenuItem,
            this.yyyyyyyToolStripMenuItem});
            this.op��o2ToolStripMenuItem.Name = "op��o2ToolStripMenuItem";
            this.op��o2ToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.op��o2ToolStripMenuItem.Text = "op��o 2";
            // 
            // xxxxToolStripMenuItem
            // 
            this.xxxxToolStripMenuItem.Name = "xxxxToolStripMenuItem";
            this.xxxxToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.xxxxToolStripMenuItem.Text = "xxxx";
            // 
            // yyyyyyyToolStripMenuItem
            // 
            this.yyyyyyyToolStripMenuItem.Name = "yyyyyyyToolStripMenuItem";
            this.yyyyyyyToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.yyyyyyyToolStripMenuItem.Text = "yyyyyyy";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(113, 6);
            // 
            // xxxToolStripMenuItem
            // 
            this.xxxToolStripMenuItem.Name = "xxxToolStripMenuItem";
            this.xxxToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.xxxToolStripMenuItem.Text = "xxx";
            // 
            // Botao1
            // 
            this.Botao1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Botao1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Botao1.Image = global::ControlesDiversos_csharp.Properties.Resources.IPML;
            this.Botao1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botao1.Name = "Botao1";
            this.Botao1.Size = new System.Drawing.Size(36, 36);
            this.Botao1.Text = "ToolStripButton1";
            this.Botao1.Click += new System.EventHandler(this.Botao1_Click);
            // 
            // Botao2
            // 
            this.Botao2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Botao2.Image = global::ControlesDiversos_csharp.Properties.Resources.group;
            this.Botao2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botao2.Name = "Botao2";
            this.Botao2.Size = new System.Drawing.Size(36, 36);
            this.Botao2.Text = "ToolStripButton2";
            this.Botao2.Click += new System.EventHandler(this.Botao2_Click);
            // 
            // Botao3
            // 
            this.Botao3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Botao3.Image = global::ControlesDiversos_csharp.Properties.Resources.homenet;
            this.Botao3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botao3.Name = "Botao3";
            this.Botao3.Size = new System.Drawing.Size(36, 36);
            this.Botao3.Text = "ToolStripButton3";
            this.Botao3.Click += new System.EventHandler(this.Botao3_Click);
            // 
            // ToolStripSeparator1
            // 
            this.ToolStripSeparator1.Name = "ToolStripSeparator1";
            this.ToolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // Botao5
            // 
            this.Botao5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Botao5.Image = global::ControlesDiversos_csharp.Properties.Resources.ICS_client;
            this.Botao5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Botao5.Name = "Botao5";
            this.Botao5.Size = new System.Drawing.Size(36, 36);
            this.Botao5.Text = "ToolStripButton1";
            this.Botao5.Click += new System.EventHandler(this.Botao5_Click);
            // 
            // ToolStripButton1
            // 
            this.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ToolStripButton1.Image = global::ControlesDiversos_csharp.Properties.Resources.keys;
            this.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButton1.Name = "ToolStripButton1";
            this.ToolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.ToolStripButton1.Text = "ToolStripButton1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(37, 36);
            this.toolStripLabel1.Text = "xxxxxx";
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Painel1,
            this.Painel2,
            this.Painel3,
            this.Painel4,
            this.Painel5,
            this.toolStripStatusLabel1});
            this.StatusStrip1.Location = new System.Drawing.Point(0, 302);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.ShowItemToolTips = true;
            this.StatusStrip1.Size = new System.Drawing.Size(700, 25);
            this.StatusStrip1.TabIndex = 6;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // Painel1
            // 
            this.Painel1.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedInner;
            this.Painel1.Name = "Painel1";
            this.Painel1.Size = new System.Drawing.Size(121, 20);
            this.Painel1.Text = "ToolStripStatusLabel1";
            this.Painel1.ToolTipText = "Mensagem Instant�nea";
            // 
            // Painel2
            // 
            this.Painel2.AutoToolTip = true;
            this.Painel2.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.Painel2.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.Painel2.Image = global::ControlesDiversos_csharp.Properties.Resources.help;
            this.Painel2.Name = "Painel2";
            this.Painel2.Size = new System.Drawing.Size(141, 20);
            this.Painel2.Text = "ToolStripStatusLabel2";
            this.Painel2.ToolTipText = "Data";
            // 
            // Painel3
            // 
            this.Painel3.Name = "Painel3";
            this.Painel3.Size = new System.Drawing.Size(121, 20);
            this.Painel3.Text = "ToolStripStatusLabel3";
            this.Painel3.ToolTipText = "Hora";
            // 
            // Painel4
            // 
            this.Painel4.AutoSize = false;
            this.Painel4.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom;
            this.Painel4.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.Painel4.Image = global::ControlesDiversos_csharp.Properties.Resources.internetconnection;
            this.Painel4.Name = "Painel4";
            this.Painel4.Size = new System.Drawing.Size(80, 20);
            this.Painel4.Text = "toolStripStatusLabel1";
            // 
            // Painel5
            // 
            this.Painel5.Name = "Painel5";
            this.Painel5.Size = new System.Drawing.Size(118, 20);
            this.Painel5.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 15);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // teste2ToolStripMenuItem
            // 
            this.teste2ToolStripMenuItem.Name = "teste2ToolStripMenuItem";
            this.teste2ToolStripMenuItem.Size = new System.Drawing.Size(12, 20);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // frm_inicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 327);
            this.ContextMenuStrip = this.ContextMenuStrip1;
            this.Controls.Add(this.StatusStrip1);
            this.Controls.Add(this.ToolStrip1);
            this.Controls.Add(this.MenuStrip1);
            this.IsMdiContainer = true;
            this.Name = "frm_inicial";
            this.Text = "Form1";
            this.ContextMenuStrip1.ResumeLayout(false);
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.ToolStrip1.ResumeLayout(false);
            this.ToolStrip1.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.StatusStrip1.ResumeLayout(false);
            this.StatusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ImageList ImageList2;
        internal System.Windows.Forms.ImageList ImageList1;
        internal System.Windows.Forms.PrintDialog PrintDialog1;
        internal System.Windows.Forms.ContextMenuStrip ContextMenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao1;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao2;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao3;
        internal System.Windows.Forms.ToolStripSeparator ToolStripMenuItem1;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_opcao4;
        internal System.Windows.Forms.ToolStripMenuItem ContextMenuStrip_Sair;
        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.ToolStripMenuItem Formul�riosToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmCheck;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmRadio;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmTab;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmScroll;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmTimer;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmList;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmDialogs;
        internal System.Windows.Forms.ToolStripMenuItem MenuFrmKeys;
        internal System.Windows.Forms.ToolStripMenuItem Menu_Sair;
        internal System.Windows.Forms.ToolStripSeparator ToolStripMenuItem2;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStrip ToolStrip1;
        internal System.Windows.Forms.ToolStripButton Botao1;
        internal System.Windows.Forms.ToolStripButton Botao2;
        internal System.Windows.Forms.ToolStripButton Botao3;
        internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator1;
        internal System.Windows.Forms.ToolStripButton Botao5;
        internal System.Windows.Forms.ToolStripButton ToolStripButton1;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.ToolStripStatusLabel Painel1;
        internal System.Windows.Forms.ToolStripStatusLabel Painel2;
        internal System.Windows.Forms.ToolStripStatusLabel Painel3;
        private System.Windows.Forms.ToolStripStatusLabel Painel4;
        private System.Windows.Forms.ToolStripStatusLabel Painel5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem op��o1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem op��o2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xxxxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yyyyyyyToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem xxxToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem teste2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    }
}

