using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_inicial : Form
    {
        public frm_inicial()
        {
            InitializeComponent();
        }

        private void MenuFrmTimer_Click(object sender, EventArgs e)
        {
            frm_Timer  Janela = new frm_Timer ();
            Janela.MdiParent = this ;
            Janela.Visible = true;

        }

        private void MenuFrmKeys_Click(object sender, EventArgs e)
        {
            frm_Keys  Janela = new frm_Keys ();
            Janela.Visible = true;

        }

        private void MenuFrmCheck_Click(object sender, EventArgs e)
        {
            frm_CheckBox Janela = new frm_CheckBox();
            Janela.Visible = true;
        }

        private void MenuFrmRadio_Click(object sender, EventArgs e)
        {
            frm_RadioButton Janela = new frm_RadioButton();
            Janela.Visible = true;
        }

        private void Botao3_Click(object sender, EventArgs e)
        {
            Painel1.Text = "Controle ToolStrip - bot�o 3";
        }


        private void Botao5_Click(object sender, EventArgs e)
        {
            Painel1.Text = "Controle ToolStrip - bot�o 5";
        }


        private void ContextMenuStrip_opcao1_Click(object sender, EventArgs e)
        {
            Painel1.Text = "Menu Contexto - op��o 1";
        }

        private void ContextMenuStrip_opcao2_Click(object sender, EventArgs e)
        {
            Painel1.Text = "Menu Contexto - op��o 2";
        }

        private void ContextMenuStrip_opcao3_Click(object sender, EventArgs e)
        {
            Painel1.Text = "Menu Contexto - op��o 3";
        }

        private void ContextMenuStrip_opcao4_Click(object sender, EventArgs e)
        {
            Painel1.Text = "Menu Contexto - op��o 4";
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            Painel2.Text = DateTime.Now.ToShortDateString();
            Painel3.Text = DateTime.Now.ToShortTimeString();
            Painel4.Text = DateTime.Now.ToString("dd/mm/yyyy");
            Painel5.Text = DateTime.Now.ToString("hh:mm:ss");
            
        }

        private void Menu_Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Botao1_Click(object sender, EventArgs e)
        {
            MenuFrmCheck_Click(sender, e);
        }

        private void Botao2_Click(object sender, EventArgs e)
        {
            MenuFrmRadio_Click(sender, e);
        }

        private void MenuFrmTab_Click(object sender, EventArgs e)
        {
            frm_ControlesDatas  Janela = new frm_ControlesDatas();
            Janela.Visible = true;
        }

        private void MenuFrmDialogs_Click(object sender, EventArgs e)
        {
            frm_Dialogs Janela = new frm_Dialogs();
            Janela.MdiParent = this;
            Janela.Visible = true;
        }

        private void MenuFrmScroll_Click(object sender, EventArgs e)
        {
            frm_ScrollBar  Janela = new frm_ScrollBar();
            Janela.Visible = true;
        }

        private void MenuFrmList_Click(object sender, EventArgs e)
        {
            frm_ListBox_ComboBox Janela = new frm_ListBox_ComboBox();
            Janela.Visible = true;
        }

        private void ToolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void teste1ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


    }
}