using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_ScrollBar : Form
    {
        public frm_ScrollBar()
        {
            InitializeComponent();
        }

        private void HScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            lbl_H_Resultado.Text = "HScrollBar1.Value = " + HScrollBar1.Value.ToString();
            Console.WriteLine("Evento Scroll   Value = {0}", HScrollBar1.Value);
        }
        private void HScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            lbl_H_Resultado2.Text = "HScrollBar1.Value = " + HScrollBar1.Value.ToString();
            Console.WriteLine("Evento ValueChanged   Value = {0}", HScrollBar1.Value);
        }

        private void VScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            lbl_V_Resultado.Text = "VScrollBar1.Value = " + VScrollBar1.Value.ToString();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            ProgressBar1.Value = ProgressBar1.Value + 1;
            lbl_ProgressBar.Text = "ProgressBar1.Value = " + ProgressBar1.Value.ToString();
            if (ProgressBar1.Value >= ProgressBar1.Maximum)
            {
                ProgressBar1.Value = ProgressBar1.Minimum;
            }
        
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBox1.CheckState == CheckState.Checked)
            {
                Timer1.Enabled = true;
                CheckBox1.Text = "Para Progress�o";
            }
            else
            {
                Timer1.Enabled = false;
                CheckBox1.Text = "Liga Progress�o";
            }
        }

        private void frm_ScrollBar_Load(object sender, EventArgs e)
        {
            ProgressBar1.Minimum = 0;
            ProgressBar1.Maximum = 100;
        }

    }
}