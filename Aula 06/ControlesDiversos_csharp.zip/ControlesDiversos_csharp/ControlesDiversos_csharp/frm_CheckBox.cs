using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControlesDiversos_csharp
{
    public partial class frm_CheckBox : Form
    {
        public frm_CheckBox()
        {
            InitializeComponent();
        }

        private void chk_opcao1_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "chk_Opcao1.CheckState =" + chk_opcao1.CheckState;
        }

        private void chk_opcao2_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "chk_Opcao2.CheckState =" + chk_opcao2.CheckState;
        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "CheckBox2.CheckState =" + CheckBox2.CheckState;
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "CheckBox1.CheckState =" + CheckBox1.CheckState;
        }

        private void chk_opcao3_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "chk_Opcao3.CheckState =" + chk_opcao3.CheckState;
        }

        private void chk_opcao4_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "chk_Opcao4.CheckState =" + chk_opcao4.CheckState;
        }

        private void CheckBox4_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "CheckBox4.CheckState =" + CheckBox4.CheckState;
        }

        private void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            lbl_Resultado.Text = "CheckBox3.CheckState =" + CheckBox3.CheckState;
        }
    }
}