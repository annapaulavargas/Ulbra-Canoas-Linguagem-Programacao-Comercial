namespace WindowsApplication1
{
    partial class frm_Cidades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Listar = new System.Windows.Forms.Button();
            this.cmb_Cidade = new System.Windows.Forms.ComboBox();
            this.txt_Codigo = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Gravar = new System.Windows.Forms.Button();
            this.btn_Novo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Listar
            // 
            this.btn_Listar.Location = new System.Drawing.Point(312, 108);
            this.btn_Listar.Name = "btn_Listar";
            this.btn_Listar.Size = new System.Drawing.Size(77, 34);
            this.btn_Listar.TabIndex = 17;
            this.btn_Listar.Text = "Listar Conte�do";
            this.btn_Listar.UseVisualStyleBackColor = true;
            this.btn_Listar.Click += new System.EventHandler(this.btn_Listar_Click);
            // 
            // cmb_Cidade
            // 
            this.cmb_Cidade.FormattingEnabled = true;
            this.cmb_Cidade.Location = new System.Drawing.Point(149, 61);
            this.cmb_Cidade.Name = "cmb_Cidade";
            this.cmb_Cidade.Size = new System.Drawing.Size(269, 21);
            this.cmb_Cidade.Sorted = true;
            this.cmb_Cidade.TabIndex = 16;
            this.cmb_Cidade.SelectedIndexChanged += new System.EventHandler(this.cmb_Cidade_SelectedIndexChanged);
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.Location = new System.Drawing.Point(146, 24);
            this.txt_Codigo.Name = "txt_Codigo";
            this.txt_Codigo.Size = new System.Drawing.Size(100, 20);
            this.txt_Codigo.TabIndex = 15;
            this.txt_Codigo.TextChanged += new System.EventHandler(this.txt_Codigo_TextChanged);
            this.txt_Codigo.Leave += new System.EventHandler(this.txt_Codigo_Leave);
            this.txt_Codigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Codigo_KeyPress);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(61, 61);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(74, 13);
            this.Label2.TabIndex = 14;
            this.Label2.Text = "Nome Cidade:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(61, 24);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(40, 13);
            this.Label1.TabIndex = 13;
            this.Label1.Text = "C�digo";
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.Location = new System.Drawing.Point(408, 108);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(77, 34);
            this.btn_Fechar.TabIndex = 12;
            this.btn_Fechar.Text = "Fechar";
            this.btn_Fechar.UseVisualStyleBackColor = true;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Location = new System.Drawing.Point(217, 108);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(77, 34);
            this.btn_Excluir.TabIndex = 11;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Gravar
            // 
            this.btn_Gravar.Location = new System.Drawing.Point(120, 108);
            this.btn_Gravar.Name = "btn_Gravar";
            this.btn_Gravar.Size = new System.Drawing.Size(77, 34);
            this.btn_Gravar.TabIndex = 10;
            this.btn_Gravar.Text = "Gravar";
            this.btn_Gravar.UseVisualStyleBackColor = true;
            this.btn_Gravar.Click += new System.EventHandler(this.btn_Gravar_Click);
            // 
            // btn_Novo
            // 
            this.btn_Novo.Location = new System.Drawing.Point(26, 108);
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(77, 34);
            this.btn_Novo.TabIndex = 9;
            this.btn_Novo.Text = "Novo";
            this.btn_Novo.UseVisualStyleBackColor = true;
            this.btn_Novo.Click += new System.EventHandler(this.btn_Novo_Click);
            // 
            // frm_Cidades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 167);
            this.Controls.Add(this.btn_Listar);
            this.Controls.Add(this.cmb_Cidade);
            this.Controls.Add(this.txt_Codigo);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.btn_Gravar);
            this.Controls.Add(this.btn_Novo);
            this.Name = "frm_Cidades";
            this.Text = "frm_Cidades";
            this.Load += new System.EventHandler(this.frm_Cidades_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btn_Listar;
        internal System.Windows.Forms.ComboBox cmb_Cidade;
        internal System.Windows.Forms.TextBox txt_Codigo;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btn_Fechar;
        internal System.Windows.Forms.Button btn_Excluir;
        internal System.Windows.Forms.Button btn_Gravar;
        internal System.Windows.Forms.Button btn_Novo;
    }
}