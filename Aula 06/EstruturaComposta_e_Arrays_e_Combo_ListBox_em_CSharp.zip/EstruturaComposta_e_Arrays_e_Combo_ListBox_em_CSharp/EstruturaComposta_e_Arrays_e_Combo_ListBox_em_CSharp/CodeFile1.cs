using System;
namespace AuxiliarProjeto
{
    public struct Pessoas
    {
        public long Codigo;
        public string Nome;
        public long Cod_Cidade;
        public string Fone;
        public string E_Mail;
    }

    public struct Cidades
    {
        public long Codigo;
        public string Nome_Cidade;
    }
    public class Auxiliar
    {
        public Pessoas[] Agenda = { };
        public Cidades[] Array_Cidade = { };
        public int Total_Agenda;
        public int Total_Cidade;
        

        public long Pesquisa_Codigo_Cidade(string nome_Cidade)
        {
            int i;
            for (i = 0; i < Total_Cidade; i++)
            {
                if (nome_Cidade == Array_Cidade[i].Nome_Cidade)
                {
                    return (Array_Cidade[i].Codigo);
                }
            }
            return 0;
        }

        public string Pesquisa_Nome_Cidade(long Codigo)
        {
            int i;
            for (i = 0; i < Total_Cidade; i++)
            {
                if (Codigo == Array_Cidade[i].Codigo)
                {
                    return (Array_Cidade[i].Nome_Cidade);
                }
            }
            return "";
        }


        public int Pesquisa_Indice_Cidade(long Codigo)
        {
            int i;
            for (i = 0; i < Total_Cidade; i++)
            {
                if (Codigo == Array_Cidade[i].Codigo)
                {
                    return (i);
                }
            }
            return -1;
        }

        public long Pesquisa_Codigo_Agenda(string nome_Pessoa)
        {
            int i;
            for (i = 0; i < Total_Agenda; i++)
            {
                if (nome_Pessoa == Agenda[i].Nome)
                {
                    return (Agenda[i].Codigo);
                }
            }
            return 0;
        }
    }

}

