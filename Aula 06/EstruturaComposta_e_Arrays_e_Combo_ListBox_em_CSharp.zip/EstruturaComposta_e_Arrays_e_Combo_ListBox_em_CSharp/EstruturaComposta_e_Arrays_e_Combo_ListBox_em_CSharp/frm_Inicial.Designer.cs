namespace WindowsApplication1
{
    partial class frm_Inicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.CadastrosAuxiliaresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnu_Cidades = new System.Windows.Forms.ToolStripMenuItem();
            this.SairToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.mnu_Sair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnu_Agenda = new System.Windows.Forms.ToolStripMenuItem();
            this.incrementaArrayCidadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CadastrosAuxiliaresToolStripMenuItem,
            this.mnu_Agenda,
            this.incrementaArrayCidadeToolStripMenuItem});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(379, 24);
            this.MenuStrip1.TabIndex = 1;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // CadastrosAuxiliaresToolStripMenuItem
            // 
            this.CadastrosAuxiliaresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnu_Cidades,
            this.SairToolStripMenuItem,
            this.mnu_Sair});
            this.CadastrosAuxiliaresToolStripMenuItem.Name = "CadastrosAuxiliaresToolStripMenuItem";
            this.CadastrosAuxiliaresToolStripMenuItem.Size = new System.Drawing.Size(124, 20);
            this.CadastrosAuxiliaresToolStripMenuItem.Text = "Cadastros Auxiliares";
            // 
            // mnu_Cidades
            // 
            this.mnu_Cidades.Name = "mnu_Cidades";
            this.mnu_Cidades.Size = new System.Drawing.Size(116, 22);
            this.mnu_Cidades.Text = "Cidades";
            this.mnu_Cidades.Click += new System.EventHandler(this.mnu_Cidades_Click);
            // 
            // SairToolStripMenuItem
            // 
            this.SairToolStripMenuItem.Name = "SairToolStripMenuItem";
            this.SairToolStripMenuItem.Size = new System.Drawing.Size(113, 6);
            // 
            // mnu_Sair
            // 
            this.mnu_Sair.Name = "mnu_Sair";
            this.mnu_Sair.Size = new System.Drawing.Size(116, 22);
            this.mnu_Sair.Text = "Sair";
            this.mnu_Sair.Click += new System.EventHandler(this.mnu_Sair_Click);
            // 
            // mnu_Agenda
            // 
            this.mnu_Agenda.Name = "mnu_Agenda";
            this.mnu_Agenda.Size = new System.Drawing.Size(60, 20);
            this.mnu_Agenda.Text = "Agenda";
            this.mnu_Agenda.Click += new System.EventHandler(this.mnu_Agenda_Click);
            // 
            // incrementaArrayCidadeToolStripMenuItem
            // 
            this.incrementaArrayCidadeToolStripMenuItem.Name = "incrementaArrayCidadeToolStripMenuItem";
            this.incrementaArrayCidadeToolStripMenuItem.Size = new System.Drawing.Size(148, 20);
            this.incrementaArrayCidadeToolStripMenuItem.Text = "Incrementa array Cidade";
            this.incrementaArrayCidadeToolStripMenuItem.Click += new System.EventHandler(this.incrementaArrayCidadeToolStripMenuItem_Click);
            // 
            // frm_Inicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 264);
            this.Controls.Add(this.MenuStrip1);
            this.Name = "frm_Inicial";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frm_Inicial_Load);
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem CadastrosAuxiliaresToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem mnu_Cidades;
        internal System.Windows.Forms.ToolStripSeparator SairToolStripMenuItem;
        internal System.Windows.Forms.ToolStripMenuItem mnu_Sair;
        internal System.Windows.Forms.ToolStripMenuItem mnu_Agenda;
        private System.Windows.Forms.ToolStripMenuItem incrementaArrayCidadeToolStripMenuItem;
    }
}

