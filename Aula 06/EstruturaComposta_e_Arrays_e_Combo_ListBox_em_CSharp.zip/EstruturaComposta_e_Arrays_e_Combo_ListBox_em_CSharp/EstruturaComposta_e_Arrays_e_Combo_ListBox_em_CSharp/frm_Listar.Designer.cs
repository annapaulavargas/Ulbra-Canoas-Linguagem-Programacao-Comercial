namespace WindowsApplication1
{
    partial class frm_Listar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.ltb_Resultado = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.Location = new System.Drawing.Point(179, 212);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(75, 23);
            this.btn_Fechar.TabIndex = 3;
            this.btn_Fechar.Text = "Fechar";
            this.btn_Fechar.UseVisualStyleBackColor = true;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // ltb_Resultado
            // 
            this.ltb_Resultado.FormattingEnabled = true;
            this.ltb_Resultado.Location = new System.Drawing.Point(12, 12);
            this.ltb_Resultado.Name = "ltb_Resultado";
            this.ltb_Resultado.Size = new System.Drawing.Size(389, 173);
            this.ltb_Resultado.TabIndex = 2;
            // 
            // frm_Listar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 247);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.ltb_Resultado);
            this.Name = "frm_Listar";
            this.Text = "frm_Listar";
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button btn_Fechar;
        internal System.Windows.Forms.ListBox ltb_Resultado;
    }
}