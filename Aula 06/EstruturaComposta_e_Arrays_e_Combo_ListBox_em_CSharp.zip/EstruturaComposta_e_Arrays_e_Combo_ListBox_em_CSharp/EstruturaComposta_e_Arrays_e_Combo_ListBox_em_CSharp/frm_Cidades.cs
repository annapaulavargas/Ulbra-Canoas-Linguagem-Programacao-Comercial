using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AuxiliarProjeto;

namespace WindowsApplication1
{
    public partial class frm_Cidades : Form
    {
        private int Indice_cmb;
        public Auxiliar aux;

        public frm_Cidades( )
        {
            InitializeComponent();
        }
        private void frm_Cidades_Load(object sender, EventArgs e)
        {
            int i;
            for (i = 0; i < aux.Total_Cidade; i++)
            {
                cmb_Cidade.Items.Add(aux.Array_Cidade[i].Nome_Cidade);
            }
            InicializaControles();
        }


        private void btn_Novo_Click(object sender, EventArgs e)
        {
            InicializaControles();
        }

        private void btn_Gravar_Click(object sender, EventArgs e)
        {
            int indice;
            
            if (txt_Codigo.Text.Length > 0) //'Altera��o
            {
                indice = aux.Pesquisa_Indice_Cidade (Convert.ToInt64(txt_Codigo.Text));
                cmb_Cidade.Items.Remove(aux.Array_Cidade[indice].Nome_Cidade);
                aux.Array_Cidade[indice].Nome_Cidade = cmb_Cidade.Text;
                cmb_Cidade.Items.Add(aux.Array_Cidade[indice].Nome_Cidade);
            }
            else // inser��o
            {
                Array.Resize (ref aux.Array_Cidade, (aux.Total_Cidade+1));
                aux.Array_Cidade[aux.Total_Cidade].Codigo = aux.Array_Cidade[aux.Total_Cidade - 1].Codigo + 1;
                aux.Array_Cidade[aux.Total_Cidade].Nome_Cidade = cmb_Cidade.Text;
                cmb_Cidade.Items.Add(cmb_Cidade.Text);
                aux.Total_Cidade += 1;
            }
            InicializaControles();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            int i;
            int resultado;

            if (cmb_Cidade.SelectedIndex >= 0)
            {
                resultado = aux.Pesquisa_Indice_Cidade(Convert.ToInt64(txt_Codigo.Text));
                for (i = resultado; i < aux.Total_Cidade - 1; i++)
                {
                    aux.Array_Cidade[i] = aux.Array_Cidade[i + 1];
                }
                aux.Total_Cidade -= 1;
                Array.Resize(ref  aux.Array_Cidade, (aux.Total_Cidade));
                cmb_Cidade.Items.RemoveAt(cmb_Cidade.SelectedIndex);
                InicializaControles();
            }
            else
            {
                MessageBox.Show("N�o foi selecionado nenhuma cidade para ser exclu�da");
            }
        }

        private void btn_Listar_Click(object sender, EventArgs e)
        {
            frm_Listar janela = new frm_Listar();
            int i;
            string linha;

            for( i = 0; i <aux.Total_Cidade; i++)
            {
                linha = aux.Array_Cidade[i].Codigo + " | " + aux.Array_Cidade[i].Nome_Cidade;
                janela.ltb_Resultado.Items.Add(linha);
                janela.Visible = true;
            }
        }

        private void btn_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void InicializaControles()
        {
            txt_Codigo.Text = "";
            cmb_Cidade.SelectedIndex = -1;
            cmb_Cidade.Text = "";
            txt_Codigo.Enabled =true;
            Indice_cmb = -1;
        }

        private void txt_Codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(13)) // Se for pressionada a tecla <ENTER> provoca evento LOSTFOCUS
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
            }
            if ((!Char.IsNumber(e.KeyChar)) && (e.KeyChar != Convert.ToChar (Keys.Back)))  // Se n�o for NUMERO desconsidera
            {
                e.Handled = true;
            }
        }

        private void cmb_Cidade_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_Codigo.Text = Convert.ToString(aux.Pesquisa_Codigo_Cidade(cmb_Cidade.Text));
            if (txt_Codigo.Text == "0")
            {
                txt_Codigo.Text = "";
            }
            else
            {
                txt_Codigo.Enabled = false;
            }
            Indice_cmb = cmb_Cidade.SelectedIndex;

        }

        private void txt_Codigo_Leave(object sender, EventArgs e)
        {
            string resultado;
            
            if (txt_Codigo.Text.Length > 0 )
            {
                resultado = aux.Pesquisa_Nome_Cidade(Convert.ToInt64(txt_Codigo.Text));
                if (resultado.Length > 0)
                {
                    txt_Codigo.Enabled = false;
                    cmb_Cidade.SelectedItem = resultado;
                }
                else
                {
                    MessageBox.Show ("C�digo Inv�lido!!!");
                    txt_Codigo.Focus();
                    cmb_Cidade.Text = "";
                    cmb_Cidade.SelectedIndex = -1;
                }
                Indice_cmb = cmb_Cidade.SelectedIndex;
            }
            else
            {
                txt_Codigo.Enabled = false;
            }
        }

        private void txt_Codigo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}