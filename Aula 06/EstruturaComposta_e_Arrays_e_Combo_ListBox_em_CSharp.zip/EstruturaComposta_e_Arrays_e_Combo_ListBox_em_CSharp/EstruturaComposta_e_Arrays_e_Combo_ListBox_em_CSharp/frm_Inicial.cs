using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AuxiliarProjeto;

namespace WindowsApplication1
{
    public partial class frm_Inicial : Form
    {
        public Auxiliar Valores = new Auxiliar();
        public frm_Inicial()
        {
            InitializeComponent();
        }

        private void mnu_Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mnu_Cidades_Click(object sender, EventArgs e)
        {
            frm_Cidades Janela = new frm_Cidades();
            /*
             * Em C #, existem dois tipos de igualdade: a igualdade de refer�ncia e valor de 
             * igualdade. igualdade de valor � o significado comumente compreendido de 
             * igualdade: isso significa que dois objetos cont�m os mesmos valores. 
             * Por exemplo: dois inteiros com o valor de 2 t�m valor igualdade. 
             * igualdade de Refer�ncia significa que n�o existem dois objetos para comparar. 
             * Em vez disso, h� duas refer�ncias de objeto, ambos se referem ao mesmo objeto. 
             * Isso pode ocorrer atrav�s de atribui��o simples, como mostrado no exemplo a seguir:
             * 
             * System.Object a = new System.Object();
             * System.Object b = a;
             * System.Object.ReferenceEquals(a, b);  //returns true
             * 
             * Neste c�digo, apenas um objeto existe, mas h� v�rias refer�ncias a esse objeto: 
             * A e B. Porque ambos se referem ao mesmo objeto, eles t�m igualdade de refer�ncia. 
             * Se dois objetos t�m igualdade de refer�ncia, ent�o eles tamb�m t�m valor igualdade, 
             * mas igualdade de valor n�o garante a igualdade de refer�ncia.
             * 
             */
            Janela.aux = Valores;
            /* 
             * Como em C# Classes s�o tipos por refer�ncia as atribui��es realizadas entre 
             * objetos da mesma classe s�o, na verdade, refer�ncias ao objeto "copiado"
            */
            Janela.Visible = true;
        }

        private void mnu_Agenda_Click(object sender, EventArgs e)
        {
            frm_Agenda Janela = new frm_Agenda();
            Janela.Visible = true;
 
        }

        private void frm_Inicial_Load(object sender, EventArgs e)
        {
            Valores.Total_Agenda = 3;
            Valores.Total_Cidade = 3;
            Array.Resize(ref Valores.Agenda, Valores.Total_Agenda);
            Array.Resize(ref Valores.Array_Cidade, Valores.Total_Cidade);

            Valores.Array_Cidade[0].Codigo = 1;
            Valores.Array_Cidade[0].Nome_Cidade = "Porto Alegre";
            Valores.Array_Cidade[1].Codigo = 2;
            Valores.Array_Cidade[1].Nome_Cidade = "Canoas";
            Valores.Array_Cidade[2].Codigo = 3;
            Valores.Array_Cidade[2].Nome_Cidade = "Gua�ba";
            Valores.Agenda[0].Codigo = 1;
            Valores.Agenda[0].Nome = "Bill Gates";
            Valores.Agenda[0].Cod_Cidade = 1;
            Valores.Agenda[0].E_Mail = "bill@gmail.com";
            Valores.Agenda[0].Fone = "51 99912333";
            Valores.Agenda[1].Codigo = 2;
            Valores.Agenda[1].Nome = "Steve Jobs";
            Valores.Agenda[1].Cod_Cidade = 1;
            Valores.Agenda[1].E_Mail = "steve@gmail.com";
            Valores.Agenda[1].Fone = "51 87766232";
            Valores.Agenda[2].Codigo = 3;
            Valores.Agenda[2].Nome = "Linus Torvalds";
            Valores.Agenda[2].Cod_Cidade = 2;
            Valores.Agenda[2].E_Mail = "linus@gmail.com";
            Valores.Agenda[2].Fone = "51 98708900";

        }

        private void incrementaArrayCidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Valores.Total_Cidade++;
            Array.Resize(ref Valores.Array_Cidade, Valores.Total_Cidade);
            Valores.Array_Cidade[Valores.Total_Cidade - 1].Codigo = Valores.Array_Cidade[Valores.Total_Cidade - 2].Codigo + 1;
            Valores.Array_Cidade[Valores.Total_Cidade - 1].Nome_Cidade = "Porto Alegre" + Convert.ToString(Valores.Array_Cidade[Valores.Total_Cidade - 1].Codigo);
            Valores.Total_Cidade++;
            Array.Resize(ref Valores.Array_Cidade, Valores.Total_Cidade);
            Valores.Array_Cidade[Valores.Total_Cidade - 1].Codigo = Valores.Array_Cidade[Valores.Total_Cidade - 2].Codigo + 1;
            Valores.Array_Cidade[Valores.Total_Cidade - 1].Nome_Cidade = "Canoas" + Convert.ToString(Valores.Array_Cidade[Valores.Total_Cidade - 1].Codigo);
            Valores.Total_Cidade++;
            Array.Resize(ref 
                Valores.Array_Cidade, Valores.Total_Cidade);
            Valores.Array_Cidade[Valores.Total_Cidade - 1].Codigo = Valores.Array_Cidade[Valores.Total_Cidade - 2].Codigo + 1;
            Valores.Array_Cidade[Valores.Total_Cidade - 1].Nome_Cidade = "Gua�ba" + Convert.ToString(Valores.Array_Cidade[Valores.Total_Cidade - 1].Codigo);

        }
    }
}