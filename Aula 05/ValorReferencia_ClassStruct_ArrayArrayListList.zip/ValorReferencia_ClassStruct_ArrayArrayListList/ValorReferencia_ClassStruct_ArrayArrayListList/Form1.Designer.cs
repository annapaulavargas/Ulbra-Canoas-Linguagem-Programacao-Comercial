﻿namespace ValorReferencia_ClassStruct_ArrayArrayListList
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.lst_List_private = new System.Windows.Forms.ListBox();
            this.lst_ArrayList_private = new System.Windows.Forms.ListBox();
            this.lst_Array_private = new System.Windows.Forms.ListBox();
            this.lst_List_public = new System.Windows.Forms.ListBox();
            this.lst_ArrayList_public = new System.Windows.Forms.ListBox();
            this.lst_Array_public = new System.Windows.Forms.ListBox();
            this.lst_List_static = new System.Windows.Forms.ListBox();
            this.lst_ArrayList_static = new System.Windows.Forms.ListBox();
            this.lst_Array_static = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(132, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(264, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Explorando as diferenças entre Array, ArrayList e List";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lst_List_private
            // 
            this.lst_List_private.FormattingEnabled = true;
            this.lst_List_private.Location = new System.Drawing.Point(347, 253);
            this.lst_List_private.Name = "lst_List_private";
            this.lst_List_private.Size = new System.Drawing.Size(85, 30);
            this.lst_List_private.TabIndex = 34;
            // 
            // lst_ArrayList_private
            // 
            this.lst_ArrayList_private.FormattingEnabled = true;
            this.lst_ArrayList_private.Location = new System.Drawing.Point(222, 253);
            this.lst_ArrayList_private.Name = "lst_ArrayList_private";
            this.lst_ArrayList_private.Size = new System.Drawing.Size(85, 30);
            this.lst_ArrayList_private.TabIndex = 33;
            // 
            // lst_Array_private
            // 
            this.lst_Array_private.FormattingEnabled = true;
            this.lst_Array_private.Location = new System.Drawing.Point(97, 253);
            this.lst_Array_private.Name = "lst_Array_private";
            this.lst_Array_private.Size = new System.Drawing.Size(85, 30);
            this.lst_Array_private.TabIndex = 32;
            // 
            // lst_List_public
            // 
            this.lst_List_public.FormattingEnabled = true;
            this.lst_List_public.Location = new System.Drawing.Point(347, 147);
            this.lst_List_public.Name = "lst_List_public";
            this.lst_List_public.Size = new System.Drawing.Size(85, 82);
            this.lst_List_public.TabIndex = 31;
            // 
            // lst_ArrayList_public
            // 
            this.lst_ArrayList_public.FormattingEnabled = true;
            this.lst_ArrayList_public.Location = new System.Drawing.Point(222, 147);
            this.lst_ArrayList_public.Name = "lst_ArrayList_public";
            this.lst_ArrayList_public.Size = new System.Drawing.Size(85, 82);
            this.lst_ArrayList_public.TabIndex = 30;
            // 
            // lst_Array_public
            // 
            this.lst_Array_public.FormattingEnabled = true;
            this.lst_Array_public.Location = new System.Drawing.Point(97, 147);
            this.lst_Array_public.Name = "lst_Array_public";
            this.lst_Array_public.Size = new System.Drawing.Size(85, 82);
            this.lst_Array_public.TabIndex = 29;
            // 
            // lst_List_static
            // 
            this.lst_List_static.FormattingEnabled = true;
            this.lst_List_static.Location = new System.Drawing.Point(347, 89);
            this.lst_List_static.Name = "lst_List_static";
            this.lst_List_static.Size = new System.Drawing.Size(85, 30);
            this.lst_List_static.TabIndex = 28;
            // 
            // lst_ArrayList_static
            // 
            this.lst_ArrayList_static.FormattingEnabled = true;
            this.lst_ArrayList_static.Location = new System.Drawing.Point(222, 89);
            this.lst_ArrayList_static.Name = "lst_ArrayList_static";
            this.lst_ArrayList_static.Size = new System.Drawing.Size(85, 30);
            this.lst_ArrayList_static.TabIndex = 27;
            // 
            // lst_Array_static
            // 
            this.lst_Array_static.FormattingEnabled = true;
            this.lst_Array_static.Location = new System.Drawing.Point(97, 89);
            this.lst_Array_static.Name = "lst_Array_static";
            this.lst_Array_static.Size = new System.Drawing.Size(85, 30);
            this.lst_Array_static.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(380, 65);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "List";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(242, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "ArrayList";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(129, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Array";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Private";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Public";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Static";
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.Location = new System.Drawing.Point(132, 315);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(264, 23);
            this.button2.TabIndex = 35;
            this.button2.Text = "Testa Diferença class e struct";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.Location = new System.Drawing.Point(132, 353);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(264, 23);
            this.button3.TabIndex = 36;
            this.button3.Text = "Formatação de Data / Hora";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 412);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lst_List_private);
            this.Controls.Add(this.lst_ArrayList_private);
            this.Controls.Add(this.lst_Array_private);
            this.Controls.Add(this.lst_List_public);
            this.Controls.Add(this.lst_ArrayList_public);
            this.Controls.Add(this.lst_Array_public);
            this.Controls.Add(this.lst_List_static);
            this.Controls.Add(this.lst_ArrayList_static);
            this.Controls.Add(this.lst_Array_static);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox lst_List_private;
        private System.Windows.Forms.ListBox lst_ArrayList_private;
        private System.Windows.Forms.ListBox lst_Array_private;
        private System.Windows.Forms.ListBox lst_List_public;
        private System.Windows.Forms.ListBox lst_ArrayList_public;
        private System.Windows.Forms.ListBox lst_Array_public;
        private System.Windows.Forms.ListBox lst_List_static;
        private System.Windows.Forms.ListBox lst_ArrayList_static;
        private System.Windows.Forms.ListBox lst_Array_static;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}